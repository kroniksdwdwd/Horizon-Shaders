#version 330 compatibility

// ============================================================
// RealisticLite - world1/deferred.fsh  (End Sky Rendering)
//
// We Render the Whole End sky in this fullscreen deferred pass.
//
// Earlier we faced a PROBLEM : gbuffers_skybasic only renders the horizon band
// in the End — the upper sky is cleared to black by vanilla and
// never reaches the gbuffers_skybasic program. So our purple sky
// only appeared at the horizon, not overhead.
//
// FIX: Move sky rendering to deferred.fsh (a fullscreen pass that
// runs on every pixel). We detect sky pixels via depthtex0 (depth =
// 1.0 = sky) and apply the rainbow sky to ALL sky pixels,
// including the upper sky.
//
// This is the same approach Complementary uses — they render the End
// sky in their deferred1 pass, not in gbuffers_skybasic.
//
// We added world-locked stars using the 3D world-direction method.
// The previous star code was screen-locked because it used
// view-space position scaled by a constant, which doesn't properly
// transform to world space. The new method uses gbufferModelViewInverse
// to convert the view-space direction to a true world-space direction,
// so stars stay fixed as the camera moves just like real stars.
// ============================================================

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform vec3  upPosition;
uniform mat4  gbufferProjectionInverse;
uniform mat4  gbufferModelViewInverse;
uniform float frameTimeCounter;

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

// ============================================================
// HSV to RGB (for time-varying hue)
// ============================================================
vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

// ============================================================
// 3D hash for world-locked stars
// Takes a world-space direction vector and returns a pseudo-random
// value in [0, 1). Because the input is a 3D world direction, the
// stars are locked to the sky environment — they stay fixed as the
// camera moves, exactly like real stars (and vanilla Minecraft stars).
// ============================================================
float starHash3D(vec3 dir) {
    return fract(sin(dot(dir, vec3(12.9898, 78.233, 45.5432))) * 43758.5453);
}

void main() {
    vec4 c = texture(colortex0, texcoord);
    float depth = texture(depthtex0, texcoord).r;

    // ---- Detect sky pixels (depth = 1.0) ----
    bool isSky = (depth >= 0.9999);

    if (isSky) {
        // ---- Reconstruct world-space direction from screen UV ----
        // 1. Screen UV → NDC (Normalized Device Coordinates)
        // 2. NDC → view-space position (via inverse projection matrix)
        // 3. view-space → world-space direction (via inverse model-view)
        //
        // The w=0 trick in step 3 means we only want a DIRECTION, not a
        // position — the translation part of the matrix is ignored, only
        // the rotation is applied. This gives us a vector fixed to the
        // world environment.
        vec4 ndc = vec4(texcoord * 2.0 - 1.0, 1.0, 1.0);
        vec4 viewPos = gbufferProjectionInverse * ndc;
        viewPos.xyz /= viewPos.w;
        vec3 nViewPos = normalize(viewPos.xyz);

        // World-space direction (this is the key fix — stars are now
        // locked to the world, not the camera)
        vec3 worldDir = normalize((gbufferModelViewInverse * vec4(nViewPos, 0.0)).xyz);

        vec3 upDir = normalize(upPosition);
        // Use the view-space direction for horizon calculations (VdotU
        // is the same whether computed in view or world space, since
        // upPosition is already in view space)
        float VdotU = dot(nViewPos, upDir);

        // ---- Time-varying rainbow color ----
        // Cycles through ALL hues of the rainbow over ~60 seconds.
        // hue goes 0→1→0: red → orange → yellow → green → cyan → blue → purple → magenta → red
        float hue = mod(frameTimeCounter * 0.017, 1.0);
        vec3 endSkyColor = hsv2rgb(vec3(hue, 0.6, 0.18)) * 1.65;

        // ---- Base sky: brighter toward horizon ----
        float absVdotU = abs(VdotU);
        float horizonFactor = pow(1.0 - absVdotU, 2.0);
        vec3 horizonColor = endSkyColor * 1.5;
        vec3 skyColor = mix(endSkyColor, horizonColor, horizonFactor);

        // ---- World-locked stars ----
        // Generate stars using the 3D world direction vector. Because
        // worldDir is fixed to the world, stars stay in place as the
        // camera moves — they're mapped to an invisible sphere
        // surrounding the player.
        
        // SIZE: The direction vector is quantized to a coarse grid
        // (cellSize = 300.0) before hashing. This means nearby
        // directions all hash to the SAME grid cell, producing a
        // star "disk" multiple pixels wide instead of a single-pixel
        // point. The grid resolution controls the star size — lower
        // cellSize = smaller stars, higher cellSize = larger stars.
        
        // A second hash with a different input is multiplied in to
        // break up the regularity and make star brightness vary.
        float cellSize = 300.0;
        vec3  starCell = floor(worldDir * cellSize);
        float starHash1 = starHash3D(starCell);
        float starHash2 = starHash3D(starCell + vec3(0.1, 0.2, 0.3));
        float star = step(0.9965, starHash1) * starHash2;

        // Star color: warm white with slight brightness variation.
        // Brightness multiplier raised (1.5 -> 1.7) to compensate
        // for the lower density — fewer stars, but each is brighter.
        vec3 starColor = vec3(1.0, 0.95, 0.9) * star * 1.7;

        // Fade stars near the horizon (so they don't appear where the
        // rainbow sky is brightest) and below the horizon
        float starFade = smoothstep(0.0, 0.3, VdotU);
        skyColor += starColor * starFade;

        // ---- Below horizon: darken ----
        if (VdotU < 0.0) {
            float groundDarken = 1.0 + VdotU;
            groundDarken = groundDarken * groundDarken;
            skyColor *= groundDarken;
        }

        // Replace the pixel color with our sky color
        c.rgb = skyColor;
    } else {
        // Non-sky pixels: original deferred enhancement
        c.rgb = pow(max(c.rgb, vec3(0.0)), vec3(0.95));
        c.rgb = (c.rgb - 0.5) * 1.08 + 0.5;
    }

    color = vec4(max(c.rgb, vec3(0.0)), c.a);
}
