#version 330 compatibility

// ============================================================
// RealisticLite - gbuffers_skybasic.fsh  (v1.6, Custom Sky Gradient)
//
// Renders the sky dome with a FULL custom gradient,
// replacing vanilla's `glcolor` entirely. This is the only way
// to get smooth control over the horizon-to-zenith transition at
// sunset as vanilla's gradient is too sharp (~30-40px transition
// band), and Options A/C (mixing toward a fixed color / estimating
// horizon color) didn't work.
//
// TECHNIQUE:
// Inspired and Adapted from Complementary Reimagined shader.
// Complementary uses 4 colors (zenith/middle/horizon/sunset)
// blended by VdotU with a separate sunset mix on top.
//
// SIMPLIFIED VERSION:
// We use 3 colors (zenith/middle/horizon) blended by VdotU, with
// a sunset color mixed in based on invNoonFactor. The colors are
// tuned to match our current sun palette (less yellow than v1.4).
//
// KEY DIFFERENCE FROM VANILLA:
// Vanilla's gradient is `glcolor = horizon * (1-VdotU) + zenith * VdotU`
// — a simple 2-color linear blend with a narrow transition zone
// at sunset (where horizon is warm and zenith is blue, the linear
// blend produces a sharp edge because the colors are very different).
// Our gradient uses a 3-color blend with a MIDDLE color between
// zenith and horizon — the middle color acts as a buffer that
// widens the transition zone, producing a smooth gradient instead
// of a sharp edge.
//
// KEY DIFFERENCE FROM Previous attempts:
// Previous attempts ADDED a sunset mix on top of vanilla's color.
// This version REPLACES vanilla's color entirely with our own
// computed gradient — full control, no vanilla artifacts.
// ============================================================

// Sun path rotation — tilts the sun's path +30° for diagonal shadows.
// Iris/OptiFine reads this constant and rotates sunPosition before it
// reaches this shader. Declared here because gbuffers_skybasic.fsh uses
// sunPosition for the sky gradient and sun glare.
const float sunPathRotation = 30.0;

uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float rainStrength;
uniform vec3 skyColor;  // vanilla's biome/tint-aware sky color — used as base tint

in vec3 viewDir;
in vec4 glcolor;

/* RENDERTARGETS: 0,1 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;

// ============================================================
// Time-of-day sun color palette — must stay in sync with
// composite.fsh and gbuffers_water.fsh. (v1.8.5 values.)
// ============================================================
vec3 getSunLightColor(float noonFactor, float sunVisibility, float rainFactor) {
    // v1.8.5 BSL inspired 'soft & soothing' palette — desaturated, pastel tones to
    // mimic a thick, soft atmosphere. Kept SDR (≤1.0) so tonemapping handles
    // final brightness. Midnight color is intentionally skipped — only Noon /
    // Golden Hour / Sunset are applied here.
    vec3 noonClearLightColor   = vec3(0.92, 0.88, 0.80);  // soft creamy white
    vec3 goldenClearLightColor = vec3(0.88, 0.70, 0.50);  // soft apricot
    vec3 sunsetClearLightColor = vec3(0.80, 0.52, 0.42);  // dusty rose

    // 3-stage blend: sunset → golden hour → noon as noonFactor goes 0 → 1.
    float blendLow  = smoothstep(0.0, 0.5, noonFactor);  // 0 at sunset, 1 at golden
    float blendHigh = smoothstep(0.5, 1.0, noonFactor);  // 0 at golden, 1 at noon
    vec3 goldenSunset = mix(sunsetClearLightColor, goldenClearLightColor, blendLow);
    vec3 dayLightColor = mix(goldenSunset, noonClearLightColor, blendHigh);

    vec3 nightClearLightColor  = 0.9 * vec3(0.15, 0.14, 0.20);
    vec3 clearLightColor = mix(nightClearLightColor, dayLightColor, sunVisibility * sunVisibility);

    vec3 dayRainLightColor   = vec3(0.21, 0.16, 0.13) * 0.85 + noonFactor * vec3(0.0, 0.02, 0.06);
    vec3 nightRainLightColor = vec3(0.03, 0.035, 0.05);
    vec3 rainLightColor      = mix(nightRainLightColor, dayRainLightColor, sunVisibility * sunVisibility) * 2.5;

    return mix(clearLightColor, rainLightColor, rainFactor);
}

// Sun/moon glare color — uses the OLD HDR palette (pre-v1.8.5) to
// preserve the glare's original brightness. The new SDR palette in
// getSunLightColor() is too dim for the glare, which needs HDR values
// to produce a visible bloom in the sky.
vec3 getSunGlareColor(float noonFactor, float sunVisibility, float rainFactor) {
    // This Brighter sun glare (overworld only). Hue values are unchanged
    // from v1.8.5 so the warm-to-cool gradient is preserved; only the HDR
    // intensity multipliers are bumped so the glare blooms more strongly
    // in composite1.fsh's bright-pass.
    vec3 noonClearLightColor   = vec3(0.92, 0.88, 0.80) * 2.4;   // creamy white, mild HDR (was 1.7)
    vec3 goldenClearLightColor = vec3(0.88, 0.70, 0.50) * 3.8;   // apricot, brighter (was 2.8)
    vec3 sunsetClearLightColor = vec3(0.80, 0.52, 0.42) * 5.2;  // dusty rose, brightest (was 3.8)
    vec3 nightClearLightColor  = 0.9 * vec3(0.15, 0.14, 0.20);

    // 3-stage blend: sunset → golden hour → noon as noonFactor goes 0 → 1.
    float blendLow  = smoothstep(0.0, 0.5, noonFactor);
    float blendHigh = smoothstep(0.5, 1.0, noonFactor);
    vec3 goldenSunset = mix(sunsetClearLightColor, goldenClearLightColor, blendLow);
    vec3 dayLightColor = mix(goldenSunset, noonClearLightColor, blendHigh);

    vec3 clearLightColor = mix(nightClearLightColor, dayLightColor, sunVisibility * sunVisibility);

    vec3 dayRainLightColor   = vec3(0.21, 0.16, 0.13) * 0.85 + noonFactor * vec3(0.0, 0.02, 0.06);
    vec3 nightRainLightColor = vec3(0.03, 0.035, 0.05);
    vec3 rainLightColor      = mix(nightRainLightColor, dayRainLightColor, sunVisibility * sunVisibility) * 2.5;

    return mix(clearLightColor, rainLightColor, rainFactor);
}

void main() {
    // ---- View direction & sun angle ----
    vec3  nViewPos     = normalize(viewDir);
    vec3  sunDir       = normalize(sunPosition);
    vec3  upDir        = normalize(upPosition);
    float VdotS        = dot(nViewPos, sunDir);
    float VdotU        = dot(nViewPos, upDir);     // 1 = zenith, 0 = horizon, -1 = nadir
    float SdotU        = dot(sunDir, upDir);
    float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
    float sunVisibility2 = sunVisibility * sunVisibility;
    float noonFactor    = sqrt(max(SdotU, 0.0));
    float invNoonFactor = 1.0 - noonFactor;        // 0 at noon, 1 at sunset/sunrise

    // ============================================================
    // v1.5 — ALL-BLUE SKY (blue anchor, lighter at horizon, deeper at zenith)
    //
    // Yellow didn't look good so we are making the whole sky blue
    // (93, 123, 190). To avoid a flat look, we vary the brightness
    // from lighter blue at the horizon to deeper blue at the zenith,
    // mimicking natural atmospheric depth (sky is brighter near the
    // horizon due to more air scattering, darker overhead).
    //
    // 4-stop gradient (horizon → zenith), all in the chosen blue hue:
    //   0.00: (170, 190, 230) light blue   — horizon (brighter)
    //   0.35: (93,  123, 190) blue anchor  — middle (the anchor)
    //   0.70: (65,  90,  150) deeper blue  — upper sky
    //   1.00: (40,  60,  110) deep blue    — zenith (darkest)
    // ============================================================

    // Blue anchor + 3 brightness variations (same hue, different lightness)
    vec3 c_light  = vec3(170.0, 190.0, 230.0) / 255.0;  // horizon — brighter blue
    vec3 c_blue   = vec3(93.0,  123.0, 190.0) / 255.0;  // blue anchor
    vec3 c_deep   = vec3(65.0,  90.0,  150.0) / 255.0;  // upper sky
    vec3 c_zenith = vec3(40.0,  60.0,  110.0) / 255.0;  // zenith — darkest blue

    // Clamp VdotU to [0, 1] for the sky (above horizon)
    float v = clamp(VdotU, 0.0, 1.0);

    // 3-segment blend with smoothstep
    vec3 finalSky;
    if (v < 0.35) {
        finalSky = mix(c_light, c_blue, smoothstep(0.0, 0.35, v));
    } else if (v < 0.70) {
        finalSky = mix(c_blue, c_deep, smoothstep(0.35, 0.70, v));
    } else {
        finalSky = mix(c_deep, c_zenith, smoothstep(0.70, 1.0, v));
    }

    // ---- NIGHT SKY GRADIENT (brighter, with horizon airglow) ----
    // Earlier it was a single flat near-black color. Then we introduced a 3-stop
    // vertical gradient. But in this version we bump the brightness ~1.6×
    // so the night is actually visible, and adds a horizon airglow ring.
    //
    // Palette stays "grayish-blueish-blackish":
    //   - Blackish: zenith still clearly dark (≈ RGB 8, 11, 16)
    //   - Blueish:  B > R, G throughout (cool undertone)
    //   - Grayish:  R ≈ G (desaturated, naturalistic)
    //
    // 3-stop vertical gradient (horizon brighter, zenith darker):
    //   v = 0.00 (horizon): (0.105, 0.125, 0.155) — brighter blue-grey
    //   v = 0.50 (middle):  (0.065, 0.082, 0.108) — transitional blue
    //   v = 1.00 (zenith):  (0.032, 0.043, 0.062) — dark blue
    vec3 nightHorizon = vec3(0.105, 0.125, 0.155);
    vec3 nightMiddle  = vec3(0.065, 0.082, 0.108);
    vec3 nightZenith  = vec3(0.032, 0.043, 0.062);

    vec3 nightSky;
    if (v < 0.5) {
        nightSky = mix(nightHorizon, nightMiddle, smoothstep(0.0, 0.5, v));
    } else {
        nightSky = mix(nightMiddle, nightZenith, smoothstep(0.5, 1.0, v));
    }

    // ---- HORIZON AIRGLOW ----
    // A soft extra brightening right at the horizon (VdotU ≈ 0),
    // simulating atmospheric haze catching distant moonlight. Adds
    // a thin warm-cool ring that separates the sky from the terrain
    // silhouette, so the horizon doesn't look like a flat dark line.
    // smoothstep(-0.05, 0.15, VdotU) = 1 above ~15° elevation,
    // 0 below ~-5° (below horizon — handled by groundDarken later).
    float airglowMask = 1.0 - smoothstep(0.0, 0.15, v);
    vec3  airglowColor = vec3(0.040, 0.045, 0.060);
    nightSky += airglowColor * airglowMask * 0.5;

    finalSky = mix(nightSky, finalSky, sunVisibility);

    // ---- RAIN DESATURATION ----
    // Overcast sky goes grey
    float skyLum = dot(finalSky, vec3(0.2126, 0.7152, 0.0722));
    finalSky = mix(finalSky, vec3(skyLum) * 0.7, rainStrength * 0.6);

    // ---- SKY GROUND DARKENING ----
    // Below horizon (VdotU < 0), darken smoothly
    float groundDarken = 1.0 + min(VdotU, 0.0);
    groundDarken = groundDarken * groundDarken;
    groundDarken = groundDarken * groundDarken;
    finalSky *= groundDarken;

    color = vec4(finalSky, 1.0);

    // ---- Sun/Moon glare (Inspired from Complementary's formula, on top of our custom sky) ----
    // VdotSML: positive when looking at the active sky body.
    float VdotSML = sunVisibility > 0.5 ? VdotS : -VdotS;

    if (VdotSML > 0.0) {
        float glareScatter = 3.0 * (2.0 - clamp(VdotS * 1000.0, 0.0, 1.0));
        glareScatter *= 1.0 - 0.75 * rainStrength * rainStrength;

        // We made visfactor 0.075 → 0.045 (overworld only): lower visfactor
        // produces a shallower falloff, so the glare extends much farther
        // from the sun's exact position. At 30° off-axis the glare is
        // ~60% brighter; at 60° it's ~100% brighter.
        float VdotSM4 = pow(abs(VdotS), glareScatter);
        float visfactor = 0.045;
        float glare = visfactor / (1.0 - (1.0 - visfactor) * VdotSM4) - visfactor;
        // We made Global brightness scale 0.7 → 1.0 (overworld only):
        // uniform ~1.43× brightness boost across all viewing angles.
        glare *= 1.0;
        glare *= 1.0 - 0.8 * rainStrength;

        vec3 glareColor;
        if (sunVisibility > 0.5) {
            // We made Extra color multiplier 1.4 → 1.8 (overworld only):
            // stacks on top of the boosted HDR palette in getSunGlareColor().
            glareColor = getSunGlareColor(noonFactor, sunVisibility, rainStrength) * 1.8;
        } else {
            glareColor = 0.9 * vec3(0.15, 0.14, 0.20) * 1.2;
        }

        float glareLum = dot(glareColor, vec3(0.2126, 0.7152, 0.0722));
        glareColor = mix(glareColor, vec3(glareLum), rainStrength);

        color.rgb += glareColor * glare;
    }

    // Sky pixels (depth = 1.0) skip the shadow and tint code in
    // composite.fsh, so colortex1 here is just a sentinel.
    normalOut = vec4(0.0);
}
