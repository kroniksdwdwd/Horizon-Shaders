#version 330 compatibility
#define main hz_pack_main
#define HZ_NFIX_viewNormal

// ============================================================
// RealisticLite - gbuffers_terrain.vsh
// Outputs view-space normal for lighting in composite.
// ============================================================

// Sun path rotation — tilts the sun's path +30° for diagonal shadows.
// Iris/OptiFine reads this constant and rotates sunPosition + shadowLightPosition
// before they reach any shader. Affects all programs globally.
const float sunPathRotation = 30.0;

// 1. Ingest the block data array from OptiFine/Iris
in vec4 mc_Entity;

out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
#ifdef HZ_NFIX_viewNormal
out vec3 hz_nfix_in_viewNormal; vec3 viewNormal;
#else
out vec3 viewNormal;
#endif
out vec3 viewPos;

// 2. Declare the output variable to carry the ID to the fragment shader
out float blockId;

void main() {
    // 3. Extract the ID (defined in block.properties)
    blockId = mc_Entity.x;

    gl_Position = ftransform();
    texcoord   = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord    = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor    = gl_Color;

    // Transform vertex normal to view space for lighting
    viewNormal = normalize(gl_NormalMatrix * gl_Normal);

    // View-space position — used by held-light distance falloff
    // (length(viewPos) = distance from camera to this pixel)
    viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
}

// face-normals (horizon-shaderport)
#undef main
out vec3 hz_nfix_vpos;
void main() {
    hz_pack_main();
    hz_nfix_in_viewNormal = viewNormal;
    hz_nfix_vpos = (gl_ModelViewMatrix * gl_Vertex).xyz;
}
