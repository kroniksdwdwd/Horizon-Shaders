#version 330 compatibility

// ============================================================
// RealisticLite - shadow.vsh
// Shadow map vertex shader with coordinate distortion.
// Distortion gives more shadow map texels to the area closest
// to the player, improving near-shadow quality without
// increasing the shadow map resolution.
// ============================================================

// Sun path rotation — tilts the sun's path +30° for diagonal shadows.
// Iris/OptiFine reads this constant and rotates sunPosition + shadowLightPosition
// before they reach any shader. Affects all programs globally.
const float sunPathRotation = 30.0;

// 1. Ingest the block data from OptiFine/Iris
// In GLSL 330, 'in' replaces the older 'attribute' keyword
in vec4 mc_Entity;

out vec2 texcoord;
out vec4 glcolor;
#ifdef HZ_NFIX_viewNormal
out vec3 hz_nfix_in_viewNormal; vec3 viewNormal;
#else
out vec3 viewNormal;
#endif

// 2. Declare the output variable to send to shadow.fsh
out float blockId;

// Distort shadow map coordinates.
// Maps the shadow frustum so that ~80% of texels cover
// the inner region near the player.
// Must match the identical distortion in composite.fsh.
// Both passes apply the same warp so lookups land on the correct texel.
float shadowDistortFactor(vec2 p) {
    return length(p) * 0.85 + 0.15;
}

void main() {
    // 3. Extract the block ID (from block.properties) for the fragment shader
    blockId = mc_Entity.x;

    vec4 pos = ftransform();

    // Apply distortion to XY in NDC shadow space [-1, 1]
    float factor = shadowDistortFactor(pos.xy / pos.w);
    pos.xy /= factor;

    gl_Position = pos;

    // Pass texture coords for alpha testing in the fragment shader
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor   = gl_Color;

    // Pass view-space normal for front-face culling in shadow.fsh.
    // In shadow view space, viewNormal.z > 0 means the face points
    // toward the light (front-facing) — these get discarded in shadow.fsh.
    viewNormal = normalize(gl_NormalMatrix * gl_Normal);
}
