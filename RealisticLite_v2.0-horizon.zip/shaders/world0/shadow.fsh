#version 330 compatibility

// ============================================================
// RealisticLite - shadow.fsh
// Shadow map fragment shader.
// Front-face culling: discards faces toward the light, recording
// back-face depth (1 block behind surface) as a natural depth buffer.
// Alpha-tests foliage, fences, and transparent geometry.
// ============================================================

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 glcolor;
#ifdef HZ_NFIX_viewNormal
in vec3 hz_nfix_in_viewNormal; vec3 viewNormal;
#else
in vec3 viewNormal;
#endif

// 1. Receive the block ID and view-space normal from shadow.vsh
in float blockId;

void main() {
    // Front-face culling: discard faces pointing toward the light.
    // In shadow view space, viewNormal.z > 0 means the face points
    // toward the light/camera. By discarding front faces, the shadow
    // map records back-face depth — 1 full block behind the surface —
    // providing a natural depth buffer that eliminates front-face acne.
    if (viewNormal.z > 0.0) discard;

    // 2. Reconstruct the integer ID (add 0.5 to prevent float rounding errors)
    int id = int(blockId + 0.5);

    // 3. The Shadow Deletion Logic
    // If the block is mapped to ID 104 in block.properties (water, glass,
    // ice — transparent glint surfaces), terminate it immediately.
    if (id == 104) {
        discard;
    }

    vec4 col = texture(gtexture, texcoord) * glcolor;

    // Discard fully transparent pixels (leaves, fences, glass panes, etc.)
    if (col.a < 0.1) discard;
}
