#version 330 compatibility
#define main hz_pack_main
#define HZ_NFIX_viewNormal

// ============================================================
// RealisticLite - gbuffers_terrain.fsh
// Writes albedo to colortex0 and encoded view-space normal
// to colortex1 for use in the lighting calculation.
//
// BSL inspired block lighting for surrounding blocks + Version B
//        texture for light source blocks (ID 105 family).
//
//        - ID 105 family: vanilla lightmap + Version B emissive
//          boost. Torch/lava/lantern texture looks exactly like
//          Version B.
//        - All other blocks: BSL inspired block lighting formula (pow^10
//          curve, warm orange color). Surrounding blocks get
//          BSL's like tight torch glow.
// ============================================================

// Block light color — warm peachy-orange RGB(255, 197, 143). Makes light source blocks
// give out warm white light to their surroundings. Scaled to *1.1 to preserve
// HDR character (matches the original vec3(1.1, 1.0, 0.5)'s tonemap behaviour).
const vec3 blocklightCol = vec3(255.0, 197.0, 143.0 * 0.8) / 255.0 * 1.35;

uniform sampler2D lightmap;
uniform sampler2D gtexture;
const float alphaTestRef = 0.1;

// Hand-held item light levels (provided by Iris/OptiFine)
uniform int heldBlockLightValue;   // Main hand light value (0-15)
uniform int heldBlockLightValue2;  // Off hand light value (0-15)
uniform int heldItemId;            // Main hand item ID (from item.properties, -1 if unmapped)
uniform int heldItemId2;           // Off hand item ID (from item.properties, -1 if unmapped)

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
#ifdef HZ_NFIX_viewNormal
in vec3 hz_nfix_in_viewNormal; vec3 viewNormal;
#else
in vec3 viewNormal;
#endif
in vec3 viewPos;

// 1. Receive the block ID from gbuffers_terrain.vsh
in float blockId;

/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;
layout(location = 2) out vec4 lightmapOut;

// ============================================================
// Held-light color tint — per-item colors from item.properties.
// Only mapped item IDs get a color tint; unmapped items fall back.
// ============================================================
vec3 getHeldLightColor(int itemId) {
    if (itemId == 200) return vec3(1.0, 0.72, 0.35);  // lantern — warm orange
    if (itemId == 202) return vec3(1.0, 0.88, 0.65);  // glowstone, shroomlight, torch — warm white
    if (itemId == 203) return vec3(0.55, 0.65, 0.90);  // sea_lantern — cool blue
    if (itemId == 206) return vec3(1.0, 0.80, 0.90);  // end_rod, froglights — pink-white
    if (itemId == 208) return vec3(1.0, 0.72, 0.35);  // copper_lantern variants — warm orange
    if (itemId == 209) return vec3(1.0, 0.72, 0.35);  // copper_torch — warm orange
    return vec3(1.0, 0.82, 0.55);  // default fallback
}

vec3 getCombinedHeldLightColor(int id1, int id2, int lv1, int lv2) {
    vec3 c1 = (lv1 > 0 && id1 >= 0) ? getHeldLightColor(id1) : vec3(1.0);
    vec3 c2 = (lv2 > 0 && id2 >= 0) ? getHeldLightColor(id2) : vec3(1.0);
    if (lv1 > 0 && lv2 > 0) {
        float w = float(lv1) / float(lv1 + lv2);
        return mix(c2, c1, w);
    }
    return (lv1 > 0) ? c1 : c2;
}

void main() {
    // 1. Reconstruct the integer ID
    int id = int(blockId + 0.5);

    // 2. Detect ID 105 family (light sources)
    bool isLightSource = (id == 105);

    // Held-light boost: boost lmcoord.x for nearby pixels based on held
    // item's light level.
    float heldLight = max(float(heldBlockLightValue), float(heldBlockLightValue2));
    vec2 adjustedLmcoord = lmcoord;
    if (heldLight > 0.0) {
        float dist = length(viewPos);
        float heldLightRange = heldLight * 1.1;
        float t = clamp(dist / heldLightRange, 0.0, 1.0);
        float heldLightFalloff = 1.0 - t * t;
        float heldLightNorm = (heldLight / 15.0) * 0.7;
        adjustedLmcoord.x = max(adjustedLmcoord.x, heldLightNorm * heldLightFalloff);
    }

    // 3. Sample albedo texture
    vec4 albedo = texture(gtexture, texcoord) * glcolor;
    if (albedo.a < alphaTestRef) discard;

    if (isLightSource) {
        // ============================================================
        // VERSION B: vanilla lightmap + emissive boost
        //
        // This is exactly how torches/lava/lanterns looked before
        // the BSL inspired changes. The torch pixel itself uses the vanilla
        // lightmap (preserving the original texture appearance)
        // plus an emissive boost.
        // ============================================================
        color = albedo * texture(lightmap, adjustedLmcoord);

        // Colored held-light tint (Version B applied this to all blocks)
        if (heldLight > 0.0) {
            float heldBoost = max(0.0, adjustedLmcoord.x - lmcoord.x);
            if (heldBoost > 0.001) {
                vec3 heldTint = getCombinedHeldLightColor(heldItemId, heldItemId2,
                                                          heldBlockLightValue, heldBlockLightValue2);
                float tintStrength = heldBoost * 0.35;
                color.rgb = mix(color.rgb, color.rgb * heldTint, tintStrength);
            }
        }

        // Version B emissive boost — flat blockDominance of 0.1 for all
        // light sources, regardless of sky light vs block light ratio.
        float blockDominance = 0.1;
        float emissiveBoost = pow(lmcoord.x, 3.0) * blockDominance;
        color.rgb *= 1.0 + emissiveBoost * 1.5;

        const vec3 lightTint = vec3(1.0, 0.8, 0.55);
        color.rgb += lightTint * emissiveBoost * emissiveBoost * 0.40;
    } else {
        // ============================================================
        // BSL inspired BLOCK LIGHTING (all non-light-source blocks)
        //
        // Replaces the vanilla lightmap lookup with BSL's like computed
        // lighting for surrounding blocks:
        //   - Sky light: from vanilla lightmap at (0, lmcoord.y)
        //   - Block light: BSL inspired formula (pow^10 curve, warm orange)
        //   - Min lighting: prevents pitch black
        // ============================================================

        // --- Sky light: sample vanilla lightmap at block light = 0 ---
        // This gives us the sky light color (daylight/night) without
        // any torch glow contribution.
        vec3 skyLightGamma = texture(lightmap, vec2(0.0, adjustedLmcoord.y)).rgb;
        vec3 skyLightLinear = skyLightGamma * skyLightGamma;

        // --- BSL inspired block light (replaces vanilla torch glow) ---
        // We did Placed vs held brightness separation (same colour for both):
        //   - Placed light (from placed torches/glowstone): -20% brightness (* 0.8)
        //   - Held light (from held items): -10% brightness (* 0.9)
        // Both use the same new blocklightCol colour.
        // heldBoost > 0 only when held light wins the max() in the boost above.
        float heldBoost = max(0.0, adjustedLmcoord.x - lmcoord.x);
        bool  heldDominant = (heldBoost > 0.001);
        float brightnessFactor = heldDominant ? 0.9 : 0.8;
        float bslBlockLight = clamp((adjustedLmcoord.x - 0.03125) * 1.06667, 0.0, 0.9333);
        float newLightmap = pow(bslBlockLight, 5.0) * 2.0 + bslBlockLight * 1.0;
        vec3 blockLighting = blocklightCol * newLightmap * newLightmap * brightnessFactor;

        // --- Min lighting ---
        vec3 minLighting = vec3(0.001) * (1.0 - lmcoord.y * lmcoord.y);

        // --- Linearize albedo (pow^2) ---
        vec3 albedoLinear = albedo.rgb * albedo.rgb;

        // --- Apply BSL inspired lighting (linear space) ---
        vec3 lighting = max(skyLightLinear + blockLighting + minLighting, vec3(0.0));
        vec3 finalLinear = albedoLinear * lighting;

        // --- Gamma encode back (sqrt) ---
        color = vec4(sqrt(max(finalLinear, vec3(0.0))), albedo.a);

        // --- Colored held-light tint ---
        if (heldLight > 0.0) {
            // heldBoost already computed above (in BSL block light section)
            if (heldBoost > 0.001) {
                vec3 heldTint = getCombinedHeldLightColor(heldItemId, heldItemId2,
                                                          heldBlockLightValue, heldBlockLightValue2);
                float tintStrength = heldBoost * 0.35;
                color.rgb = mix(color.rgb, color.rgb * heldTint, tintStrength);
            }
        }
    }

    // 4. NORMAL OUTPUT
    normalOut = vec4(viewNormal * 0.5 + 0.5, 1.0);

    // 5. MATERIAL FLAG (combined foliage + light-source flag in colortex2.z)
    float materialFlag = (id == 101) ? 1.0 : (isLightSource ? 0.5 : 0.0);

    // colortex2.a = 1.0 ALWAYS because Iris uses this as a "pixel drawn" signal.
    lightmapOut = vec4(lmcoord, materialFlag, 1.0);
}

// face-normals (horizon-shaderport)
#undef main
in vec3 hz_nfix_vpos;
mat3 hz_nfix_rw;
mat3 hz_nfix_rv;
void hz_nfix_frame() {
    vec3 hz_n = cross(dFdx(hz_nfix_vpos), dFdy(hz_nfix_vpos));
    hz_n = dot(hz_n, hz_n) > 1e-24 ? normalize(hz_n) : vec3(0.0, 0.0, 1.0);
    if (dot(hz_n, hz_nfix_vpos) > 0.0) hz_n = -hz_n;
    mat3 hz_v = mat3(gl_ModelViewMatrix);
    vec3 hz_w = transpose(hz_v) * hz_n;
    vec3 hz_a = abs(hz_w);
    float hz_m = max(hz_a.x, max(hz_a.y, hz_a.z));
    if (hz_m > 0.97) hz_w = step(vec3(hz_m), hz_a) * sign(hz_w);
    hz_w = normalize(hz_w);
    vec3 hz_t = abs(hz_w.y) > 0.9 ? vec3(1.0, 0.0, 0.0) : normalize(cross(vec3(0.0, 1.0, 0.0), hz_w));
    hz_nfix_rw = mat3(hz_t, hz_w, cross(hz_t, hz_w));
    hz_nfix_rv = hz_v * hz_nfix_rw * transpose(hz_v);
}
void main() {
    hz_nfix_frame();
    viewNormal = hz_nfix_rv * hz_nfix_in_viewNormal;
    hz_pack_main();
}
