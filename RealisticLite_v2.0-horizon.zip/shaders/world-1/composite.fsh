#version 330 compatibility

// ============================================================
// RealisticLite - composite.fsh
// Dynamic Shadow Mapping  (PCF soft shadows)
// + filmic tone mapping for contrast/colour grading
// ============================================================

/*
const int colortex0Format = RGBA16F;
*/

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D depthtex0;
uniform sampler2DShadow shadowtex0;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

uniform vec3 shadowLightPosition;
uniform vec3 fogColor;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float rainStrength;

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

// Block light color — warm peachy-orange RGB(255, 197, 143). Makes light source blocks
// give out warm white light to their surroundings. Scaled to *1.1 to preserve
// HDR character (matches the original vec3(1.1, 1.0, 0.5)'s tonemap behaviour).
// Must match gbuffers_terrain.fsh's constant.
const vec3 blocklightCol = vec3(255.0, 197.0, 143.0 * 0.8) / 255.0 * 1.35;

// Sun path rotation — tilts the sun's path +10° for diagonal shadows.
// Iris/OptiFine reads this constant and rotates sunPosition + shadowLightPosition
// before they reach this shader. Must be declared here too because composite.fsh
// uses shadowLightPosition and sunPosition directly.
const float sunPathRotation = 10.0;

vec3 screenToViewPos(vec2 uv, float depth) {
    vec4 ndc  = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 view = gbufferProjectionInverse * ndc;
    return view.xyz / view.w;
}

// Shadow coordinate with a single constant normal offset applied in view
// space. This is the simplest "normal way" of doing the offset: push the
// sample position along the surface normal by a fixed distance before
// transforming to shadow clip space. We accept Peter Panning (objects
// appearing to float above their cast shadow) in exchange for eliminating
// shadow acne entirely — every other combination (slope-scaled, distortion-
// scaled, center-mixed) left bright lines we could not remove.
vec3 getShadowCoords(vec3 viewPos, vec3 viewNormal, out float distortionFactor) {
    // Constant normal offset in view space. 0.08 = 8cm. Large enough to
    // push past acne at grazing angles; accepts some Peter Panning.
    float normalOffset = 0.08;
    vec3 biasedViewPos = viewPos + viewNormal * normalOffset;

    // Transform biased position to shadow clip space.
    vec4 playerPos     = gbufferModelViewInverse * vec4(biasedViewPos, 1.0);
    vec4 shadowViewPos = shadowModelView * playerPos;
    vec4 shadowClipPos = shadowProjection * shadowViewPos;
    shadowClipPos.xyz /= shadowClipPos.w;

    float dist = length(shadowClipPos.xy);
    distortionFactor = dist * 0.85 + 0.15;

    shadowClipPos.xy /= distortionFactor;
    return shadowClipPos.xyz * 0.5 + 0.5;
}

// Interleaved Gradient Noise — pseudo-random per-pixel rotation.
// Creates uniform static noise that TAA can easily erase.
float getIGN(vec2 pixelCoord) {
    vec3 magic = vec3(0.06711056, 0.00583715, 52.9829189);
    return fract(magic.z * fract(dot(pixelCoord, magic.xy)));
}

// 32-tap Poisson Disk — mathematically distributed within a unit circle.
const int NUM_TAPS = 32;
const vec2 poissonDisk[NUM_TAPS] = vec2[NUM_TAPS](
    vec2(-0.8415174, -0.2227183), vec2(-0.3541164, -0.6696614),
    vec2(-0.7600871,  0.4907106), vec2(-0.0684784, -0.9234898),
    vec2( 0.2870195, -0.6558482), vec2(-0.6405786, -0.7302487),
    vec2( 0.6560942, -0.6128485), vec2(-0.1654316, -0.2646274),
    vec2( 0.3533887, -0.2310168), vec2( 0.8252273, -0.2606554),
    vec2( 0.3228945,  0.1837064), vec2( 0.8143257,  0.2215688),
    vec2(-0.2529944,  0.1770087), vec2( 0.1709949,  0.6469695),
    vec2( 0.6017122,  0.6946927), vec2(-0.3544326,  0.6728081),
    vec2(-0.2198086, -0.5821556), vec2( 0.0694582, -0.5186591),
    vec2( 0.5369651, -0.1130635), vec2(-0.0959411, -0.0152438),
    vec2(-0.5283407, -0.0242131), vec2(-0.5055009, -0.3708892),
    vec2( 0.0460481,  0.3168272), vec2( 0.4497184,  0.4705593),
    vec2(-0.5600609,  0.2389146), vec2(-0.1558296,  0.4285702),
    vec2( 0.2185561, -0.8926955), vec2(-0.2797686, -0.9231718),
    vec2( 0.6053351, -0.8710344), vec2( 0.9022669,  0.5323926),
    vec2( 0.4005886,  0.8778949), vec2(-0.0631627,  0.8912445)
);

// 32-tap Rotated Poisson Disk PCF with hardware bilinear filtering.
// Each tap uses sampler2DShadow for hardware depth comparison (4 sub-samples
// per tap = 128 effective depth tests). The disk is rotated per-pixel using
// IGN to shatter staircase banding into high-frequency noise.
// The blur radius scales with distortionFactor for consistent world-space
// penumbra across the shadow map.
// ============================================================
// Out-of-bounds sentinel.
// calculateShadowPCF returns this when the fragment is outside
// the shadow map's XY or Z coverage. Callers must check for it
// and treat out-of-bounds pixels as fully lit (shadowFactor = 1.0),
// bypassing the shadow floor and grazing fade entirely.
// ============================================================
const float SHADOW_OUT_OF_BOUNDS = -1.0;

float calculateShadowPCF(vec3 shadowCoord, float distortionFactor, vec2 screenCoord) {
    // ============================================================
    // Out-of-bounds check.
    //   - XY < 0.001 or > 0.999: pixel is outside the shadow map's
    //     square coverage in screen space.
    //   - Z > 1.0: pixel is behind the shadow camera's far plane.
    //   - Z < 0.0: pixel is in front of the shadow camera's near
    //     plane.
    // All three cases mean "no shadow data available" — return the
    // sentinel so the caller can fully light this pixel.
    // ============================================================
    if (any(lessThan(shadowCoord.xy, vec2(0.001))) ||
        any(greaterThan(shadowCoord.xy, vec2(0.999))) ||
        shadowCoord.z > 1.0 || shadowCoord.z < 0.0) {
        return SHADOW_OUT_OF_BOUNDS;
    }

    // 12 texels at 2048 resolution — 1.5× wider penumbra than the previous
    // 8-texel kernel, softening shadow edges. Density stays within tolerance
    // for 32 taps × 4 hardware sub-samples (128 effective tests).
    float baseBlurRadius = 12.0 / 2048.0;
    float scaledRadius = baseBlurRadius * distortionFactor;

    float noise = getIGN(screenCoord);
    float angle = noise * 6.28318530718;

    float s = sin(angle);
    float c = cos(angle);
    mat2 rotationMatrix = mat2(c, -s, s, c);

    float shadowVisibility = 0.0;
    for (int i = 0; i < NUM_TAPS; i++) {
        vec2 rotatedOffset = rotationMatrix * poissonDisk[i];
        vec2 finalOffset = rotatedOffset * scaledRadius;
        vec3 sampleCoord = vec3(shadowCoord.xy + finalOffset, shadowCoord.z);
        shadowVisibility += texture(shadowtex0, sampleCoord);
    }
    return shadowVisibility / float(NUM_TAPS);
}

vec3 getSunLightColor(float noonFactor, float sunVisibility, float rainFactor) {
    // BSL inspired 'soft & soothing' palette — desaturated, pastel tones to
    // mimic a thick, soft atmosphere. Kept SDR (≤1.0) so tonemapping handles
    // final brightness. Midnight color (vec3(0.12, 0.18, 0.28)) is intentionally
    // skipped — only Noon / Golden Hour / Sunset are applied here.
    vec3 noonClearLightColor   = vec3(0.92, 0.88, 0.80);  // soft creamy white
    vec3 goldenClearLightColor = vec3(0.88, 0.70, 0.50);  // soft apricot
    vec3 sunsetClearLightColor = vec3(0.80, 0.52, 0.42);  // dusty rose

    // 3-stage blend: sunset → golden hour → noon as noonFactor goes 0 → 1.
    float blendLow  = smoothstep(0.0, 0.5, noonFactor);  // 0 at sunset, 1 at golden
    float blendHigh = smoothstep(0.5, 1.0, noonFactor);  // 0 at golden, 1 at noon
    vec3 goldenSunset = mix(sunsetClearLightColor, goldenClearLightColor, blendLow);
    vec3 dayLightColor = mix(goldenSunset, noonClearLightColor, blendHigh);

    vec3 nightClearLightColor  = 0.9 * vec3(0.15, 0.14, 0.20);
    vec3 clearLightColor = mix(nightClearLightColor, dayLightColor, sunVisibility * sunVisibility);

    vec3 dayRainLightColor   = vec3(0.21, 0.16, 0.13) * 0.85 + noonFactor * vec3(0.0, 0.02, 0.06);
    vec3 nightRainLightColor = vec3(0.03, 0.035, 0.05);
    vec3 rainLightColor      = mix(nightRainLightColor, dayRainLightColor, sunVisibility * sunVisibility) * 2.5;
    return mix(clearLightColor, rainLightColor, rainFactor);
}

// ============================================================
// MAIN
// ============================================================
void main() {
    vec4  c     = texture(colortex0, texcoord);
    float depth = texture(depthtex0, texcoord).r;
    bool isSky = (depth >= 0.9999);

    vec3 viewPos = vec3(0.0);
    if (!isSky) {
        viewPos = screenToViewPos(texcoord, depth);
    }

    vec4  handCheck    = texture(colortex1, texcoord);
    bool  isHandPixel  = (handCheck.a > 0.4 && handCheck.a < 0.6);

    if (isHandPixel) {
        color = vec4(max(c.rgb, vec3(0.0)), c.a);
        return;
    }

    vec3  sunDir        = normalize(sunPosition);
    vec3  upDir         = normalize(upPosition);
    float SdotU         = dot(sunDir, upDir);
    float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
    float noonFactor    = sqrt(max(SdotU, 0.0));

    vec3  sunLightColor = getSunLightColor(noonFactor, sunVisibility, rainStrength);

    // --------------------------------------------------------
    // Dynamic shadow Setup
    // --------------------------------------------------------
    float shadowFactor    = 1.0;
    float skyLightAmt     = 0.0;
    float isPlanarFoliage = 0.0;

    if (!isSky) {
        vec4  normalSample   = texture(colortex1, texcoord);
        vec4  lightmapSample = texture(colortex2, texcoord);
        float normalAlpha    = normalSample.a;
        
        skyLightAmt     = lightmapSample.g; 
        isPlanarFoliage = step(0.9, lightmapSample.b);  // 1.0 only for z >= 0.9 (foliage ID 101). 0.5 (light source ID 105) → 0.0 (not foliage)

        bool noShadowData = (normalAlpha < 0.1);
        bool hasNormal    = (normalAlpha > 0.75);

        if (noShadowData) {
            shadowFactor = 1.0;
        } else {
            vec3 lightDir = normalize(shadowLightPosition);

            // 1. TRUE PHYSICAL NORMAL
            // The actual geometry normal — used as the base for the
            // lighting normal below.
            vec3 realViewNormal = normalSample.rgb * 2.0 - 1.0;

            // 2. FAKE OPTICAL NORMAL
            // We bend the normal upward strictly for the lighting aesthetic.
            vec3 lightingNormal = realViewNormal;
            if (isPlanarFoliage > 0.5) {
                lightingNormal = upDir;
            }

            // --- LIGHTING CALCULATION (Uses Fake Normal) ---
            float rawNdotL   = dot(lightingNormal, lightDir);
            float cosTheta   = hasNormal ? clamp(rawNdotL, 0.0, 1.0) : 0.5;

            // Sample the shadow map with a constant Normal Offset
            // (Peter Panning accepted — see getShadowCoords)
            float shadowDistortion;
            vec3 shadowPos = getShadowCoords(viewPos, realViewNormal, shadowDistortion);
            float rawShadow = calculateShadowPCF(shadowPos, shadowDistortion, gl_FragCoord.xy);

            if (rawShadow == SHADOW_OUT_OF_BOUNDS) {
                // Pixel is outside the shadow map coverage (beyond the
                // 8-chunk shadow distance). Treat as fully lit by direct
                // sunlight — skip the shadow floor and grazing fade.
                // The warm sun tint code below will apply at full strength.
                shadowFactor = 1.0;
            } else {
                // Calculate final lit shadow value
                // v1.8.5: Shadow floor unified at 0.56 for all 3 dimensions
                float shadowLit = mix(0.56, 1.0, rawShadow);

                // Foliage doesn't need grazing fade because we forced its lighting normal upward
                float grazingFade = mix(smoothstep(0.0, 0.15, cosTheta), 1.0, isPlanarFoliage);

                // Final Shadow Factor
                // v1.8.5: Shadow floor unified at 0.56 for all 3 dimensions
                shadowFactor = mix(0.56, shadowLit, grazingFade);
            }
        }
    }

    // Apply clean shadows
    c.rgb *= shadowFactor;

    // Shadow tint — cool blue ambient light filling shadowed regions.
    // RGB(38, 76, 127) normalized to luminance 1.0 to preserve
    // brightness while shifting hue toward cool blue.
    if (!isSky) {
        vec3 shadowTint = vec3(38.0, 76.0, 127.0) / 255.0;
        float tintLum = dot(shadowTint, vec3(0.2126, 0.7152, 0.0722));
        vec3 normalizedTint = shadowTint / max(tintLum, 1e-4);
        float shadowStrength = 1.0 - shadowFactor;
        c.rgb = mix(c.rgb, c.rgb * normalizedTint, shadowStrength * 0.5);
    }

    // ============================================================
    // TORCH GLOW SHADOW EXEMPTION
    //
    // shadowFactor darkened the entire pixel — including the torch
    // glow that was baked into colortex0 by gbuffers_terrain.fsh.
    // Torches should glow at full intensity regardless of sun shadows
    // (a torch under a tree should light up the ground around it).
    //
    // We re-add the torch glow × (1 - shadowFactor) so it's restored
    // to approximately full intensity. When blockLight = 0 (no torch
    // nearby), torchGlow = 0 and there's no change. The boost is
    // modulated by c.rgb to preserve the surface's albedo tint.
    // ============================================================
    if (!isSky) {
        vec4 lmSample = texture(colortex2, texcoord);
        float blockLight = lmSample.r;
        float bslBlockLight = clamp((blockLight - 0.03125) * 1.06667, 0.0, 0.9333);
        float newLightmap = pow(bslBlockLight, 5.0) * 2.0 + bslBlockLight * 1.0;
        // v2.3 — new placed-light colour + 20% brightness reduction
        vec3 torchGlow = blocklightCol * newLightmap * newLightmap * 0.8;
        // Exemption strength reduced to 0.1 — lanterns were too
        // bright in shadowy areas. Affects all light sources equally.
        c.rgb += c.rgb * torchGlow * (1.0 - shadowFactor) * 0.1;
    }

    // --------------------------------------------------------
    // Warm Sun-Light Tint
    // --------------------------------------------------------
    if (!isSky) {
        float sunInfluence = skyLightAmt * shadowFactor * sunVisibility;
        float tintLum   = dot(sunLightColor, vec3(0.2126, 0.7152, 0.0722));
        float whiteRef  = 1.0;
        vec3  tintScale = sunLightColor / max(tintLum, 1e-4) * mix(1.0, tintLum / whiteRef, 0.5);

        const float tintStrength = 0.85;
        vec3  finalTint  = mix(vec3(1.0), tintScale, tintStrength);
        c.rgb = mix(c.rgb, c.rgb * finalTint, sunInfluence);
    }

    // --------------------------------------------------------
    // Nether Ambient Light
    // --------------------------------------------------------
    // Warm dim red-orange ambient simulating lava/netherrack bounce.
    // Slightly higher than previous (0.055)
    if (!isSky) {
        const vec3 netherAmbient = vec3(0.055, 0.030, 0.020);  // warm dim red-orange
        c.rgb += netherAmbient;
    }

    // HDR and Fog adjustments
    c.rgb *= mix(1.0, 0.995, smoothstep(0.7, 1.0, depth));
    const float exposure = 1.05;
    c.rgb *= exposure;

    float vignette = distance(texcoord, vec2(0.5));
    vignette = 1.0 - smoothstep(0.35, 0.85, vignette) * 0.04;
    c.rgb *= vignette;

    if (!isSky) {
        float dist = length(viewPos);

        // ---- Analytic Fog ----
        // Constant-density exponential fog (Beer-Lambert) with an
        // 80% cap so distant terrain never fully disappears.
        //
        //   - density 0.002 — very gradual ramp: ~18% fog at 100
        //     blocks, ~33% at 200 blocks, ~80% (capped) at ~800+
        //     blocks.
        //
        // Height attenuation intentionally omitted — fog density is
        // the same at every Y.
        const float density = 0.002;
        const float cap     = 0.80;

        // Beer-Lambert fog factor with cap
        float fogFactor = 1.0 - exp(-density * dist);
        fogFactor = min(fogFactor, cap);

        // Mix vanilla fogColor into the scene proportional to fogFactor
        c.rgb = mix(c.rgb, fogColor, fogFactor);
    }

    color = vec4(max(c.rgb, vec3(0.0)), c.a);
}