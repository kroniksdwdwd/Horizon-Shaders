#version 330 compatibility

uniform sampler2D lightmap;
uniform sampler2D gtexture;
uniform vec4      entityColor;     // hit-flash / dye overlay
const float alphaTestRef = 0.1;

// Block light color — warm peachy-orange RGB(255, 197, 143). Same as gbuffers_terrain.fsh.
// Scaled to *1.1 to preserve HDR character.
const vec3 blocklightCol = vec3(255.0, 197.0, 143.0 * 0.8) / 255.0 * 1.35;

// Hand-held item light levels (provided by Iris/OptiFine)
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform int heldItemId;
uniform int heldItemId2;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
#ifdef HZ_NFIX_viewNormal
in vec3 hz_nfix_in_viewNormal; vec3 viewNormal;
#else
in vec3 viewNormal;
#endif
in vec3 viewPos;

/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;
layout(location = 2) out vec4 lightmapOut;

void main() {
    // Held-light boost (no tint in this pass — only gbuffers_terrain tints)
    float heldLight = max(float(heldBlockLightValue), float(heldBlockLightValue2));
    vec2 adjustedLmcoord = lmcoord;
    if (heldLight > 0.0) {
        float dist = length(viewPos);
        float heldLightRange = heldLight * 1.1;
        float t = clamp(dist / heldLightRange, 0.0, 1.0);
        float heldLightFalloff = 1.0 - t * t;
        float heldLightNorm = (heldLight / 15.0) * 0.7;
        adjustedLmcoord.x = max(adjustedLmcoord.x, heldLightNorm * heldLightFalloff);
    }

    vec4 albedo = texture(gtexture, texcoord) * glcolor;

    // -------------------------------------------------------
    // BSL inspired BLOCK LIGHTING (matches gbuffers_terrain.fsh)
    // Replaces vanilla lightmap with custom BSL block lighting so mobs
    // and players use the same warm-white placed-light colour as terrain.
    //   - Placed light (from placed torches): new colour, -20% brightness (*0.8)
    //   - Held light (from held items): new colour, -10% brightness (*0.9)
    // -------------------------------------------------------
    vec3 skyLightGamma  = texture(lightmap, vec2(0.0, adjustedLmcoord.y)).rgb;
    vec3 skyLightLinear = skyLightGamma * skyLightGamma;
    float bslBlockLight = clamp((adjustedLmcoord.x - 0.03125) * 1.06667, 0.0, 0.9333);
    float newLightmap   = pow(bslBlockLight, 5.0) * 2.0 + bslBlockLight * 1.0;
    float heldBoost     = max(0.0, adjustedLmcoord.x - lmcoord.x);
    bool  heldDominant  = (heldBoost > 0.001);
    float brightnessFactor = heldDominant ? 0.9 : 0.8;
    vec3 blockLighting  = blocklightCol * newLightmap * newLightmap * brightnessFactor;
    vec3 minLighting    = vec3(0.001) * (1.0 - lmcoord.y * lmcoord.y);
    vec3 albedoLinear   = albedo.rgb * albedo.rgb;
    vec3 lighting       = max(skyLightLinear + blockLighting + minLighting, vec3(0.0));
    vec3 finalLinear    = albedoLinear * lighting;
    color = vec4(sqrt(max(finalLinear, vec3(0.0))), albedo.a);
    // Apply entity colour (hit flash / dye) AFTER lighting so the overlay
    // is always at full intensity, matching vanilla behaviour where the
    // damage flash remains clearly visible even in deep shadow.
    color.rgb = mix(color.rgb, entityColor.rgb, entityColor.a);
    if (color.a < alphaTestRef) discard;

    normalOut = vec4(viewNormal * 0.5 + 0.5, 1.0);
    lightmapOut = vec4(lmcoord, 0.0, 1.0);  // .a = 1.0: pixel drawn (Iris requires this), .z = 0.0: not foliage/light
}
