#version 330 compatibility

// ============================================================
// RealisticLite - composite2.fsh  (Block ID Bloom — H blur)
// ============================================================
// Horizontal 9-tap Gaussian blur of the bright-pass.
// Reads colortex3 (bright extract from composite1), applies
// separable Gaussian along X, writes to colortex4.
// ============================================================

uniform sampler2D colortex3;

in vec2 texcoord;

/* RENDERTARGETS: 4 */
layout(location = 0) out vec4 bloom;

void main() {
    vec2 texSize = vec2(textureSize(colortex3, 0));
    float texel  = 1.0 / texSize.x;

    // 9-tap Gaussian weights (normalized, symmetric).
    const float weights[5] = float[](
        0.227027, 0.1945946, 0.1216216, 0.054054, 0.016216
    );

    // Spread widens the kernel for a wider, softer glow.
    const float spread = 4.0;

    vec3 result = texture(colortex3, texcoord).rgb * weights[0];
    for (int i = 1; i < 5; i++) {
        float offset = texel * spread * float(i);
        result += texture(colortex3, texcoord + vec2(offset, 0.0)).rgb * weights[i];
        result += texture(colortex3, texcoord - vec2(offset, 0.0)).rgb * weights[i];
    }

    bloom = vec4(result, 1.0);
}
