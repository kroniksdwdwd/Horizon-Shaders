#version 330 compatibility
#define main hz_pack_main
#define HZ_NFIX_viewNormal

// ============================================================
// RealisticLite - gbuffers_water.vsh  (v1.6, Water colour/opacity tuning)
//
// WHY THIS FILE EXISTS:
//   RealisticLite previously had no gbuffers_water program, so all
//   water fell through the Iris fallback chain
//     gbuffers_water -> gbuffers_terrain -> gbuffers_textured
//   and was rendered by gbuffers_terrain.fsh — which just multiplied
//   (texture * lightmap * vertexcolor). That gave vanilla blue water
//   at vanilla opacity.
// ============================================================

// Sun path rotation — tilts the sun's path +10° for diagonal shadows.
// Iris/OptiFine reads this constant and rotates sunPosition + shadowLightPosition
// before they reach any shader. Affects all programs globally.
const float sunPathRotation = 10.0;

out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
#ifdef HZ_NFIX_viewNormal
out vec3 hz_nfix_in_viewNormal; vec3 viewNormal;
#else
out vec3 viewNormal;
#endif
out vec3 viewPos;

void main() {
    gl_Position = ftransform();
    texcoord   = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord    = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor    = gl_Color;

    // View-space position — fragment shader needs this for:
    //   - length(viewPos)    = distance from camera (for distance-based effects)
    viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;

    // Transform vertex normal to view space (same as gbuffers_terrain.vsh).
    viewNormal = normalize(gl_NormalMatrix * gl_Normal);
}

// face-normals (horizon-shaderport)
#undef main
out vec3 hz_nfix_vpos;
void main() {
    hz_pack_main();
    hz_nfix_in_viewNormal = viewNormal;
    hz_nfix_vpos = (gl_ModelViewMatrix * gl_Vertex).xyz;
}
