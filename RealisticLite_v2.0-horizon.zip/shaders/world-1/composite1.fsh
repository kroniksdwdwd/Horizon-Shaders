#version 330 compatibility

// ============================================================
// RealisticLite - composite1.fsh  (Block ID Bloom — bright-pass)
// ============================================================
// Bright-pass extraction gated by the isLightSource flag in
// colortex2.a (written by gbuffers_terrain.fsh for ID 105 blocks
// only). Only ID 105 blocks (torches, glowstone, lava, sea
// lanterns, etc.) bloom and everything else is excluded regardless
// of luminance, eliminating false bloom on specular highlights,
// white blocks, sky edges, and bright entities.
//
// A soft luminance modulation is still applied so brighter light
// sources bloom more than dimmer ones, but the GATE is the
// isLightSource flag, not luminance.
// ============================================================

uniform sampler2D colortex0;
uniform sampler2D colortex2;

in vec2 texcoord;

/* RENDERTARGETS: 3 */
layout(location = 0) out vec4 bloom;

void main() {
    vec3 c = texture(colortex0, texcoord).rgb;
    // Read the material flag from colortex2.b (.z channel).
    // gbuffers_terrain writes:
    //   0.0 = default, 0.5 = light source (ID 105), 1.0 = foliage (ID 101)
    // Only 0.5 (light source) triggers bloom. The range check
    // (flag > 0.4 && flag < 0.6) ensures only the 0.5 sentinel blooms —
    // foliage (1.0) and default (0.0) do NOT bloom.
    float materialFlag = texture(colortex2, texcoord).b;
    float isLightSource = (materialFlag > 0.4 && materialFlag < 0.6) ? 1.0 : 0.0;

    // Soft luminance modulation:
    //   - Dim torch (lum ~0.3) → ~0.27 bloom factor
    //   - Bright sea lantern (lum ~1.5) → 1.0 bloom factor
    //   - Very dim redstone torch (lum ~0.15) → 0.0 (too dim to bloom)
    float luminance = dot(c, vec3(0.2126, 0.7152, 0.0722));
    float amount = isLightSource * smoothstep(0.2, 0.8, luminance);

    bloom = vec4(c * amount, 1.0);
}
