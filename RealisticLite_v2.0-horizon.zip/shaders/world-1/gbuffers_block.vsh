#version 330 compatibility

// ============================================================
// RealisticLite - gbuffers_block.vsh
// Block entities (chests, barrels, etc.) — normal output
// for lighting. Same pattern as gbuffers_terrain.
// ============================================================

out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
#ifdef HZ_NFIX_viewNormal
out vec3 hz_nfix_in_viewNormal; vec3 viewNormal;
#else
out vec3 viewNormal;
#endif
out vec3 viewPos;

void main() {
    gl_Position = ftransform();
    texcoord   = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord    = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor    = gl_Color;
    viewNormal = normalize(gl_NormalMatrix * gl_Normal);
    viewPos    = (gl_ModelViewMatrix * gl_Vertex).xyz;
}
