#version 330 compatibility

// ============================================================
// RealisticLite - gbuffers_hand.fsh  (v1.3, Bug #2 fix)
// Dedicated fragment shader for the first-person hand / held-item
// view model.
//
// BUG BEING FIXED:
//   In first-person view, cutout blocks (leaves, seagrass, flowers)
//   were visible THROUGH the player's hand, while solid blocks
//   (stone, dirt) were correctly occluded. The hand was behaving
//   as if translucent over cutout geometry.
//
// ROOT CAUSE:
//   Our shader previously had NO gbuffers_hand program. Per the Iris
//   docs (https://shaders.properties/current/reference/programs/gbuffers/),
//   the fallback chain for the hand is:
//     gbuffers_hand -> gbuffers_textured_lit -> gbuffers_textured
//   Since this pack also lacks gbuffers_textured_lit, the hand was
//   rendered by gbuffers_textured — the same program used by clouds,
//   weather, glint, beacon beams, particles, and spider eyes.
//   Iris applies hand-specific GL state (correct depth range with
//   MC_HAND_DEPTH, depth-write enabled, depth-test against world
//   geometry) ONLY when gbuffers_hand exists. Without it, the hand
//   inherited gbuffers_textured's GL state, which does not write
//   depth correctly for the hand view model — so cutout blocks
//   drawn earlier in the opaque pass bled through the hand's
//   alpha-tested pixels.
//
//   Solid blocks (stone, dirt) didn't bleed through because they
//   are fully opaque and wrote depth in the solid terrain pass
//   before the hand; the hand's colour write overwrote their colour
//   directly. Cutout blocks (leaves, grass, flowers) also wrote
//   colour, but at pixels where the hand's own alpha test discarded
//   the hand fragment, the cutout block colour underneath was what
//   remained visible — producing the see-through effect.
//
// THE FIX:
//   We created this dedicated gbuffers_hand program. Iris now routes
//   hand draw calls here and applies the correct hand GL state.
//   The shader logic itself is identical to gbuffers_textured.fsh
//   (texture * vertex colour * lightmap, alpha-tested, with the
//   colortex1 = vec4(0.0) sentinel that tells composite.fsh to
//   skip the shadow lookup for these pixels).
//
// WHY colortex1 = vec4(0.0):
//   The hand view model uses a camera-attached transform with
//   MC_HAND_DEPTH applied. composite.fsh's world-position
//   reconstruction (gbufferProjectionInverse / gbufferModelViewInverse)
//   can't correctly un-project these pixels, so we mark them as
//   "no shadow data" (alpha < 0.1) — composite.fsh then leaves
//   them fully lit. Same sentinel as gbuffers_textured.fsh.
//
// Reference:
//   - https://shaders.properties/current/reference/programs/gbuffers/
//   - https://shaders.properties/current/reference/macros/mc_hand_depth/
//   - https://shaders.properties/current/reference/buffers/depthtex/
// ============================================================

uniform sampler2D lightmap;
uniform sampler2D gtexture;
uniform sampler2DShadow shadowtex0;

// Shadow matrices (same as composite.fsh)
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

// Sun path rotation — tilts the sun's path +10° for diagonal shadows.
// Iris/OptiFine reads this constant and rotates sunPosition before it
// reaches this shader. Declared here because gbuffers_hand.fsh uses
// sunPosition for the hand's directional shading.
const float sunPathRotation = 10.0;
uniform vec3  sunPosition;       // v1.4 — for hand directional shading
uniform vec3  upPosition;        // v1.4 — for sunVisibility computation
uniform float rainStrength;      // v1.4 — for rain gate
const float alphaTestRef = 0.1;

// Block light color — warm peachy-orange RGB(255, 197, 143). Same as gbuffers_terrain.fsh.
// Scaled to *1.1 to preserve HDR character.
const vec3 blocklightCol = vec3(255.0, 197.0, 143.0 * 0.8) / 255.0 * 1.35;

// Hand-held item light levels (provided by Iris/OptiFine)
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform int heldItemId;
uniform int heldItemId2;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
#ifdef HZ_NFIX_viewNormal
in vec3 hz_nfix_in_viewNormal; vec3 viewNormal;
#else
in vec3 viewNormal;
#endif
in vec3 viewPos;

/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;
layout(location = 2) out vec4 lightmapOut;

// 32-tap Rotated Poisson Disk PCF with hardware bilinear filtering — identical
// to the function in composite.fsh so hand and terrain shadows have
// the same quality.
// Uses sampler2DShadow for hardware depth comparison (128 effective tests).
// The disk is rotated per-pixel using IGN to shatter staircase banding.
// The blur radius scales with distortionFactor for consistent world-space penumbra.
// Out-of-bounds check returns 1.0 (fully lit) for pixels outside
// the [0.001, 0.999] shadow map range — prevents dark rings at
// the edge of the shadow frustum.

// Interleaved Gradient Noise — pseudo-random per-pixel rotation.
float getIGN(vec2 pixelCoord) {
    vec3 magic = vec3(0.06711056, 0.00583715, 52.9829189);
    return fract(magic.z * fract(dot(pixelCoord, magic.xy)));
}

// 32-tap Poisson Disk
const int NUM_TAPS = 32;
const vec2 poissonDisk[NUM_TAPS] = vec2[NUM_TAPS](
    vec2(-0.8415174, -0.2227183), vec2(-0.3541164, -0.6696614),
    vec2(-0.7600871,  0.4907106), vec2(-0.0684784, -0.9234898),
    vec2( 0.2870195, -0.6558482), vec2(-0.6405786, -0.7302487),
    vec2( 0.6560942, -0.6128485), vec2(-0.1654316, -0.2646274),
    vec2( 0.3533887, -0.2310168), vec2( 0.8252273, -0.2606554),
    vec2( 0.3228945,  0.1837064), vec2( 0.8143257,  0.2215688),
    vec2(-0.2529944,  0.1770087), vec2( 0.1709949,  0.6469695),
    vec2( 0.6017122,  0.6946927), vec2(-0.3544326,  0.6728081),
    vec2(-0.2198086, -0.5821556), vec2( 0.0694582, -0.5186591),
    vec2( 0.5369651, -0.1130635), vec2(-0.0959411, -0.0152438),
    vec2(-0.5283407, -0.0242131), vec2(-0.5055009, -0.3708892),
    vec2( 0.0460481,  0.3168272), vec2( 0.4497184,  0.4705593),
    vec2(-0.5600609,  0.2389146), vec2(-0.1558296,  0.4285702),
    vec2( 0.2185561, -0.8926955), vec2(-0.2797686, -0.9231718),
    vec2( 0.6053351, -0.8710344), vec2( 0.9022669,  0.5323926),
    vec2( 0.4005886,  0.8778949), vec2(-0.0631627,  0.8912445)
);

// ============================================================
// Out-of-bounds sentinel.
// calculateShadowPCF returns this when the fragment is outside
// the shadow map's XY or Z coverage. Callers must check for it
// and treat out-of-bounds pixels as fully lit (shadow = 1.0),
// bypassing the shadow floor and grazing fade entirely.
// ============================================================
const float SHADOW_OUT_OF_BOUNDS = -1.0;

float calculateShadowPCF(vec3 shadowCoord, float distortionFactor, vec2 screenCoord) {
    // ============================================================
    // Out-of-bounds check.
    //   - XY < 0.001 or > 0.999: pixel is outside the shadow map's
    //     square coverage in screen space.
    //   - Z > 1.0: pixel is behind the shadow camera's far plane.
    //   - Z < 0.0: pixel is in front of the shadow camera's near
    //     plane.
    // All three cases mean "no shadow data available" — return the
    // sentinel so the caller can fully light this pixel.
    // ============================================================
    if (any(lessThan(shadowCoord.xy, vec2(0.001))) ||
        any(greaterThan(shadowCoord.xy, vec2(0.999))) ||
        shadowCoord.z > 1.0 || shadowCoord.z < 0.0) {
        return SHADOW_OUT_OF_BOUNDS;
    }

    // 12 texels at 2048 resolution — 1.5× wider penumbra than the previous
    // 8-texel kernel, softening shadow edges. Must match composite.fsh so
    // hand and world shadows have consistent edge softness.
    float baseBlurRadius = 12.0 / 2048.0;
    float scaledRadius = baseBlurRadius * distortionFactor;

    float noise = getIGN(screenCoord);
    float angle = noise * 6.28318530718;

    float s = sin(angle);
    float c = cos(angle);
    mat2 rotationMatrix = mat2(c, -s, s, c);

    float shadowVisibility = 0.0;
    for (int i = 0; i < NUM_TAPS; i++) {
        vec2 rotatedOffset = rotationMatrix * poissonDisk[i];
        vec2 finalOffset = rotatedOffset * scaledRadius;
        vec3 sampleCoord = vec3(shadowCoord.xy + finalOffset, shadowCoord.z);
        shadowVisibility += texture(shadowtex0, sampleCoord);
    }
    return shadowVisibility / float(NUM_TAPS);
}

// Shadow coordinate with a single constant normal offset applied in view
// space. Identical to the function in composite.fsh.
// We accept Peter Panning (objects appearing to float above their cast
// shadow) in exchange for eliminating shadow acne entirely.
vec3 getShadowCoords(vec3 viewPos, vec3 viewNormal, out float distortionFactor) {
    // Constant normal offset in view space. 0.08 = 8cm.
    float normalOffset = 0.08;
    vec3 biasedViewPos = viewPos + viewNormal * normalOffset;

    // Transform biased position to shadow clip space.
    vec4 playerPos     = gbufferModelViewInverse * vec4(biasedViewPos, 1.0);
    vec4 shadowViewPos = shadowModelView * playerPos;
    vec4 shadowClipPos = shadowProjection * shadowViewPos;
    shadowClipPos.xyz /= shadowClipPos.w;

    float dist = length(shadowClipPos.xy);
    distortionFactor = dist * 0.85 + 0.15;

    shadowClipPos.xy /= distortionFactor;
    return shadowClipPos.xyz * 0.5 + 0.5;
}

void main() {
    // v1.4 — Fixing "hand behaving as translucent" bug.
    //
    // PROBLEM: Even after a (dedicated gbuffers_hand program) and
    // (hand shadows), the hand was still behaving as translucent
    // so you could see terrain (including solid blocks, not just cutout)
    // through it. The transparency was direction/angle/sunlight dependent.
    //
    // ROOT CAUSE #1: The alpha test was applied AFTER multiplying by glcolor
    // and the lightmap texture. The vanilla lightmap's alpha channel (and
    // sometimes glcolor's alpha) can be < 1.0, which reduces color.a below
    // the 0.1 threshold. Pixels that should be visible were being discarded
    // — and discarded pixels don't write color OR depth, so the underlying
    // terrain showed through. The direction/sunlight dependence came from
    // the lightmap changing with time of day and block light levels.
    //
    // ROOT CAUSE #2: composite.fsh applied warm tint + fog + depth darkening
    // to hand pixels. The hand's depth is compressed by MC_HAND_DEPTH (~0.125),
    // which made composite.fsh's viewPos reconstruction produce bogus positions.
    // The warm tint code read colortex2 (which at discarded hand edge pixels
    // contained STALE block data underneath), causing blocks to show through.
    //
    // FIX: Apply alpha test to RAW texture alpha before multiplication (fixes #1).
    // Compute hand shading DIRECTLY here in gbuffers_hand.fsh and mark hand
    // pixels with alpha=0.5 sentinel so composite.fsh skips ALL post-processing (fixes #2).
    vec4 texColor = texture(gtexture, texcoord);

    // Alpha test on RAW texture alpha (before glcolor/lightmap multiplication)
    if (texColor.a < alphaTestRef) discard;

    // Held-light boost — for the hand itself, use a slightly reduced effect
    // (5% reduction via * 0.95) to avoid over-brightening the held item.
    float heldLight = max(float(heldBlockLightValue), float(heldBlockLightValue2));
    vec2 adjustedLmcoord = lmcoord;
    if (heldLight > 0.0) {
        float dist = length(viewPos);
        float heldLightRange = heldLight * 1.1;
        float t = clamp(dist / heldLightRange, 0.0, 1.0);
        float heldLightFalloff = 1.0 - t * t;
        float heldLightNorm = (heldLight / 15.0) * 0.7;
        adjustedLmcoord.x = max(adjustedLmcoord.x, heldLightNorm * heldLightFalloff * 0.95);
    }

    // -------------------------------------------------------
    // BSL inspired BLOCK LIGHTING (matches gbuffers_terrain.fsh)
    // Replaces vanilla lightmap with custom BSL block lighting so the hand
    // uses the same warm-white placed-light colour as terrain.
    //   - Placed light (from placed torches): new colour, -20% brightness (*0.8)
    //   - Held light (from held items): new colour, -10% brightness (*0.9)
    // Alpha preserved from texColor.a so the hand stays fully opaque.
    // -------------------------------------------------------
    vec3 skyLightGamma  = texture(lightmap, vec2(0.0, adjustedLmcoord.y)).rgb;
    vec3 skyLightLinear = skyLightGamma * skyLightGamma;
    float bslBlockLight = clamp((adjustedLmcoord.x - 0.03125) * 1.06667, 0.0, 0.9333);
    float newLightmap   = pow(bslBlockLight, 5.0) * 2.0 + bslBlockLight * 1.0;
    float handheldBoost = max(0.0, adjustedLmcoord.x - lmcoord.x);
    bool  handHeldDominant = (handheldBoost > 0.001);
    float handBrightnessFactor = handHeldDominant ? 0.9 : 0.8;
    vec3 blockLighting  = blocklightCol * newLightmap * newLightmap * handBrightnessFactor;
    vec3 minLighting    = vec3(0.001) * (1.0 - lmcoord.y * lmcoord.y);
    vec3 albedoLinear   = (texColor.rgb * glcolor.rgb) * (texColor.rgb * glcolor.rgb);
    vec3 lighting       = max(skyLightLinear + blockLighting + minLighting, vec3(0.0));
    vec3 finalLinear    = albedoLinear * lighting;
    color = vec4(sqrt(max(finalLinear, vec3(0.0))), texColor.a);

    // ============================================================
    // Dynamic world shadow on the hand (hitbox bypass method)
    //
    // PROBLEM: The hand view model uses MC_HAND_DEPTH, which compresses
    // the hand's depth. composite.fsh's world-position reconstruction
    // can't un-project this correctly, so the hand was previously
    // marked with a sentinel (alpha=0.5) that told composite.fsh to
    // skip ALL post-processing — including world shadows.
    //
    // This meant the hand had NO dynamic world shadow — just a simple
    // normal-based directional shade.
    //
    // NEW METHOD: Compute the shadow HERE in gbuffers_hand.fsh, using
    // Position Offsetting to bypass the player's own third-person
    // hitbox (which would otherwise cast a shadow on the hand).
    //
    //   1. Get the camera's forward direction in view space
    //   2. Offset the hand position forward by 2 blocks along this
    //      direction — mathematically, the shadow lookup happens 2
    //      blocks in front of the player, safely outside their own
    //      hitbox shadow
    //   3. Transform the offset position to shadow space
    //   4. Apply 3×3 PCF sampling (9 taps) for soft shadow edges
    //   5. Multiply by vanilla sky light (lmcoord.y) — the "safety
    //      net" that prevents the hand from glowing indoors
    // ============================================================

    // --- Camera forward direction (view space) ---
    // The camera looks down -Z in view space (OpenGL convention).
    // So the forward direction is vec3(0, 0, -1) in view space.
    // We offset the hand's view position forward by 2 blocks.
    // This is a hitbox bypass (NOT an acne fix) — it moves the shadow
    // lookup 2 blocks ahead so the player's own body doesn't cast a
    // shadow on the hand.
    vec3 viewForward   = vec3(0.0, 0.0, -1.0);
    vec3 offsetViewPos = viewPos + viewForward * 2.0;

    // --- Shadow coordinate with a constant Normal Offset
    // (Peter Panning accepted — same function as composite.fsh) ---
    // sunDir is computed here for the bias; it's also used later for
    // the directional shading.
    vec3 sunDir = normalize(sunPosition);
    float shadowDistortion;
    vec3 shadowPos = getShadowCoords(offsetViewPos, viewNormal, shadowDistortion);

    // --- 32-tap Rotated Poisson Disk PCF (matches composite.fsh) ---
    // The hand is very close to the camera, so a 1-tap shadow would
    // look extremely pixelated. High-quality PCF softens the edge.
    // Uses the same calculateShadowPCF() function as composite.fsh so
    // hand and terrain shadows have identical quality.
    float handShadow = calculateShadowPCF(shadowPos, shadowDistortion, gl_FragCoord.xy);

    if (handShadow == SHADOW_OUT_OF_BOUNDS) {
        // Hand pixel is outside the shadow map coverage (beyond the
        // 8-chunk shadow distance). Treat as fully lit — skip the
        // shadow floor and the sky-light gate. (In practice, the
        // hand is always close to the camera so this rarely fires,
        // but the check is here for code consistency with composite.fsh.)
        handShadow = 1.0;
    }

    // Remap to match composite.fsh's shadowLit range (0.56 shadow -> 1.0 lit)
    handShadow = mix(0.56, 1.0, handShadow);

    // --- Vanilla lightmap safety net ---
    // Shadow maps are unreliable indoors (the hand is often inside a
    // cave or under a roof). Multiply by lmcoord.y (sky light) so the
    // shadow factor fades to 1.0 (no darkening) when there's no sky
    // light — this prevents the hand from glowing in caves and ensures
    // a seamless transition between dynamic outdoor shadows and
    // ambient indoor darkness.
    //
    // lmcoord.y = 1.0 outdoors (full sky light) -> handShadow applies fully
    // lmcoord.y = 0.0 indoors (cave) -> handShadow is fully overridden to 1.0
    float skyLightGate = lmcoord.y;
    float finalHandShadow = mix(1.0, handShadow, skyLightGate);

    // ============================================================
    // v1.4 — Hand directional shading (kept from previous version).
    // Combined with the new dynamic shadow for a complete look.
    // ============================================================
    vec3  upDir         = normalize(upPosition);
    float SdotU         = dot(sunDir, upDir);
    float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;

    // Normal-based directional shading (kept from v1.4)
    float cosTheta    = clamp(dot(viewNormal, sunDir), 0.0, 1.0);
    float normalBoost = pow(cosTheta, 0.8) * 0.5;
    float shadowFactor = 0.5 + normalBoost;
    // Night gate — at night, hand keeps just the 0.5 base
    shadowFactor = mix(0.5, shadowFactor, sunVisibility);

    // Combine: dynamic world shadow × directional shading
    color.rgb *= shadowFactor * finalHandShadow;

    // v1.4 — Hand sentinel: alpha = 0.5 tells composite.fsh to skip
    // ALL post-processing (shadows, warm tint, fog, depth darkening).
    // The hand color computed above is the FINAL color.
    normalOut = vec4(viewNormal * 0.5 + 0.5, 0.5);

    // Write lightmap coords (for completeness, though composite.fsh
    // won't read them for hand pixels anymore)
    lightmapOut = vec4(lmcoord, 0.0, 1.0);  // .a = 1.0: pixel drawn (Iris requires this), .z = 0.0: not foliage/light
}
