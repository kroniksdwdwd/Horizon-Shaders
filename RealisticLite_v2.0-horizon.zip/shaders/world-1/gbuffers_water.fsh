#version 330 compatibility
#define main hz_pack_main
#define HZ_NFIX_viewNormal

// ============================================================
// RealisticLite - gbuffers_water.fsh  (v1.6, Water colour/opacity tuning)
//
// One change from the previous behaviour (water rendered by
// gbuffers_terrain.fsh):
//
//   1. WATER COLOUR / OPACITY TUNING
//      Vanilla water is a fairly saturated blue with low transparency.
//      The goal is "slightly less blue and slightly more
//      transparent". We do both:
//        - Reduce the blue channel by 12% and boost the red/green by
//          8% — pulls the colour toward a teal/cyan rather than pure
//          blue, matching what real water looks like in daylight.
//        - Multiply alpha by 0.78 — lets you see more of the riverbed
//          / ocean floor through the water surface.
//      The shifts are deliberately subtle ("slightly") — they should
//      feel like a refinement, not a complete recolour.
// ============================================================

uniform sampler2D lightmap;
uniform sampler2D gtexture;

// Sun path rotation — tilts the sun's path +10° for diagonal shadows.
// Iris/OptiFine reads this constant and rotates sunPosition before it
// reaches this shader.
const float sunPathRotation = 10.0;
const float alphaTestRef = 0.1;

// Block light color — warm peachy-orange RGB(255, 197, 143). Same as gbuffers_terrain.fsh.
// Scaled to *1.1 to preserve HDR character.
const vec3 blocklightCol = vec3(255.0, 197.0, 143.0 * 0.8) / 255.0 * 1.35;

// Hand-held item light levels (provided by Iris/OptiFine)
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform int heldItemId;
uniform int heldItemId2;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
#ifdef HZ_NFIX_viewNormal
in vec3 hz_nfix_in_viewNormal; vec3 viewNormal;
#else
in vec3 viewNormal;
#endif
in vec3 viewPos;

/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;
layout(location = 2) out vec4 lightmapOut;

void main() {
    // Held-light boost (no tint in this pass — only gbuffers_terrain tints)
    float heldLight = max(float(heldBlockLightValue), float(heldBlockLightValue2));
    vec2 adjustedLmcoord = lmcoord;
    if (heldLight > 0.0) {
        float dist = length(viewPos);
        float heldLightRange = heldLight * 1.1;
        float t = clamp(dist / heldLightRange, 0.0, 1.0);
        float heldLightFalloff = 1.0 - t * t;
        float heldLightNorm = (heldLight / 15.0) * 0.7;
        adjustedLmcoord.x = max(adjustedLmcoord.x, heldLightNorm * heldLightFalloff);
    }

    vec4 albedo = texture(gtexture, texcoord) * glcolor;
    if (albedo.a < alphaTestRef) discard;

    // -------------------------------------------------------
    // BSL inspired BLOCK LIGHTING (matches gbuffers_terrain.fsh)
    // Replaces vanilla lightmap with custom BSL block lighting so water
    // uses the same warm-white placed-light colour as terrain.
    //   - Placed light (from placed torches): new colour, -20% brightness (*0.8)
    //   - Held light (from held items): new colour, -10% brightness (*0.9)
    // -------------------------------------------------------
    vec3 skyLightGamma  = texture(lightmap, vec2(0.0, adjustedLmcoord.y)).rgb;
    vec3 skyLightLinear = skyLightGamma * skyLightGamma;
    float bslBlockLight = clamp((adjustedLmcoord.x - 0.03125) * 1.06667, 0.0, 0.9333);
    float newLightmap   = pow(bslBlockLight, 5.0) * 2.0 + bslBlockLight * 1.0;
    float heldBoost     = max(0.0, adjustedLmcoord.x - lmcoord.x);
    bool  heldDominant  = (heldBoost > 0.001);
    float brightnessFactor = heldDominant ? 0.9 : 0.8;
    vec3 blockLighting  = blocklightCol * newLightmap * newLightmap * brightnessFactor;
    vec3 minLighting    = vec3(0.001) * (1.0 - lmcoord.y * lmcoord.y);
    vec3 albedoLinear   = albedo.rgb * albedo.rgb;
    vec3 lighting       = max(skyLightLinear + blockLighting + minLighting, vec3(0.0));
    vec3 finalLinear    = albedoLinear * lighting;
    color = vec4(sqrt(max(finalLinear, vec3(0.0))), albedo.a);

    // -------------------------------------------------------
    // 1. WATER COLOUR / OPACITY TUNING
    // -------------------------------------------------------
    // Slightly less blue: pull the colour toward teal/cyan by
    // reducing blue and boosting red+green.
    color.r *= 1.08;
    color.g *= 1.08;
    color.b *= 0.88;

    // Slightly more transparent: multiply alpha by 0.78 so more of
    // the riverbed shows through. Vanilla water alpha is ~0.65 in
    // most biomes, so this drops it to ~0.51 — clearly more see-
    // through but still recognizably water.
    color.a *= 0.78;

    // -------------------------------------------------------
    // Encode normal + write lightmap (same as gbuffers_terrain.fsh)
    // -------------------------------------------------------
    normalOut   = vec4(viewNormal * 0.5 + 0.5, 1.0);
    lightmapOut = vec4(lmcoord, 0.0, 1.0);  // .a = 1.0: pixel drawn (Iris requires this), .z = 0.0: not foliage/light
}

// face-normals (horizon-shaderport)
#undef main
in vec3 hz_nfix_vpos;
mat3 hz_nfix_rw;
mat3 hz_nfix_rv;
void hz_nfix_frame() {
    vec3 hz_n = cross(dFdx(hz_nfix_vpos), dFdy(hz_nfix_vpos));
    hz_n = dot(hz_n, hz_n) > 1e-24 ? normalize(hz_n) : vec3(0.0, 0.0, 1.0);
    if (dot(hz_n, hz_nfix_vpos) > 0.0) hz_n = -hz_n;
    mat3 hz_v = mat3(gl_ModelViewMatrix);
    vec3 hz_w = transpose(hz_v) * hz_n;
    vec3 hz_a = abs(hz_w);
    float hz_m = max(hz_a.x, max(hz_a.y, hz_a.z));
    if (hz_m > 0.97) hz_w = step(vec3(hz_m), hz_a) * sign(hz_w);
    hz_w = normalize(hz_w);
    vec3 hz_t = abs(hz_w.y) > 0.9 ? vec3(1.0, 0.0, 0.0) : normalize(cross(vec3(0.0, 1.0, 0.0), hz_w));
    hz_nfix_rw = mat3(hz_t, hz_w, cross(hz_t, hz_w));
    hz_nfix_rv = hz_v * hz_nfix_rw * transpose(hz_v);
}
void main() {
    hz_nfix_frame();
    viewNormal = hz_nfix_rv * hz_nfix_in_viewNormal;
    hz_pack_main();
}
