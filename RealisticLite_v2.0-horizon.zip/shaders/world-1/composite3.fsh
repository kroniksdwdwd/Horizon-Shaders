#version 330 compatibility

// ============================================================
// RealisticLite - composite3.fsh  (Block ID Bloom — V blur)
// ============================================================
// Vertical 9-tap Gaussian blur of the horizontally-blurred
// bright-pass. Reads colortex4 (H-blur from composite2), applies
// the same separable Gaussian along Y, writes the final bloom
// buffer back to colortex3. final.fsh reads colortex3 and adds
// it to the scene before tonemapping.
// ============================================================

uniform sampler2D colortex4;

in vec2 texcoord;

/* RENDERTARGETS: 3 */
layout(location = 0) out vec4 bloom;

void main() {
    vec2 texSize = vec2(textureSize(colortex4, 0));
    float texel  = 1.0 / texSize.y;

    // Same weights and spread as composite2.fsh — must match for a
    // symmetric Gaussian blur.
    const float weights[5] = float[](
        0.227027, 0.1945946, 0.1216216, 0.054054, 0.016216
    );
    const float spread = 4.0;

    vec3 result = texture(colortex4, texcoord).rgb * weights[0];
    for (int i = 1; i < 5; i++) {
        float offset = texel * spread * float(i);
        result += texture(colortex4, texcoord + vec2(0.0, offset)).rgb * weights[i];
        result += texture(colortex4, texcoord - vec2(0.0, offset)).rgb * weights[i];
    }

    bloom = vec4(result, 1.0);
}
