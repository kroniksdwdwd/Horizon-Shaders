#version 330 compatibility

uniform sampler2D lightmap;
uniform sampler2D gtexture;

const float alphaTestRef = 0.1;

// Iris render stage — used to detect cloud pixels specifically.
// Clouds share this program with the held hand, weather, glint, particles,
// beacon beams, and spider eyes. renderStage lets us target only cloud
// draws and leave everything else untouched.
#ifdef IS_IRIS
uniform int renderStage;
#endif

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;

/* RENDERTARGETS: 0,1 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;

void main() {
        color = texture(gtexture, texcoord) * glcolor;
        color *= texture(lightmap, lmcoord);
        if (color.a < alphaTestRef) {
                discard;
        }

        // ============================================================
        // Creamy-white bright clouds
        //
        // Boosts cloud pixels toward a warm, bright creamy-white so they
        // stand out clearly against the blue sky instead of looking grey.
        //
        // Why a multiplier and not a flat color replace:
        //   The lightmap already provides time-of-day coloring (cool blue
        //   at night, warm pink at sunset, neutral white at noon). A flat
        //   replace would lose that natural variation. Multiplying keeps
        //   the time-of-day tint while shifting the hue warm and pushing
        //   brightness into HDR so ACES tonemaps the result to bright
        //   white with a creamy tint.
        //
        // The numbers:
        //   vec3(1.0, 0.97, 0.90) — warm cream hue (R > G > B), matching
        //     typical cream hex values like #FFFDD0 or #FFFEF0.
        //   × 1.6 — HDR brightness boost. Daytime clouds land around
        //     (1.6, 1.55, 1.44), which ACES compresses to ~0.99 brightness
        //     with a warm tint. Clearly brighter than the blue sky
        //     (~0.7 brightness) without blowing out to flat white.
        //
        // Alpha is left untouched — vanilla cloud textures have soft
        // alpha edges, and forcing alpha = 1.0 would make cloud edges
        // look hard-cut.
        // ============================================================
        #ifdef IS_IRIS
        if (renderStage == MC_RENDER_STAGE_CLOUDS) {
                color.rgb *= vec3(1.0, 0.97, 0.90) * 1.6;
        }
        #endif

        // This program renders clouds, the held item/hand view model, weather,
        // and other things with no reliable world-space position (see the
        // "noShadowData" check in composite.fsh). Without this, colortex1 at
        // this pixel would just be whatever the last thing drawn here left
        // behind — e.g. distant terrain a cloud is drawn in front of — and
        // composite.fsh would run the shadow calculation using that stale
        // terrain normal against this cloud's own depth, producing wrong,
        // sometimes near-black results. Alpha < 0.1 here guarantees this
        // pixel is always correctly read as "leave fully lit, no shadow data".
        normalOut = vec4(0.0);
}
