#version 330 compatibility

// ============================================================
// RealisticLite - gbuffers_block.fsh
// Emissive light-source boost. colortex0 is now a 16-bit float HDR
// buffer (declared in composite.fsh), so this is left as real
// radiance — no clamp needed, see gbuffers_terrain.fsh for details.
// ============================================================

uniform sampler2D lightmap;
uniform sampler2D gtexture;
const float alphaTestRef = 0.1;

// Block light color — warm peachy-orange RGB(255, 197, 143). Same as gbuffers_terrain.fsh.
// Scaled to *1.1 to preserve HDR character.
const vec3 blocklightCol = vec3(255.0, 197.0, 143.0 * 0.8) / 255.0 * 1.35;

// Hand-held item light levels (provided by Iris/OptiFine)
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform int heldItemId;
uniform int heldItemId2;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
#ifdef HZ_NFIX_viewNormal
in vec3 hz_nfix_in_viewNormal; vec3 viewNormal;
#else
in vec3 viewNormal;
#endif
in vec3 viewPos;

/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;
layout(location = 2) out vec4 lightmapOut;

void main() {
    // Held-light boost (no tint in this pass — only gbuffers_terrain tints)
    float heldLight = max(float(heldBlockLightValue), float(heldBlockLightValue2));
    vec2 adjustedLmcoord = lmcoord;
    if (heldLight > 0.0) {
        float dist = length(viewPos);
        float heldLightRange = heldLight * 1.1;
        float t = clamp(dist / heldLightRange, 0.0, 1.0);
        float heldLightFalloff = 1.0 - t * t;
        float heldLightNorm = (heldLight / 15.0) * 0.7;
        adjustedLmcoord.x = max(adjustedLmcoord.x, heldLightNorm * heldLightFalloff);
    }

    vec4 albedo = texture(gtexture, texcoord) * glcolor;
    if (albedo.a < alphaTestRef) discard;

    // -------------------------------------------------------
    // BSL inspired BLOCK LIGHTING (matches gbuffers_terrain.fsh)
    // Replaces vanilla lightmap with custom BSL block lighting so block
    // entities (chests, etc.) use the same warm-white placed-light colour
    // as terrain.
    //   - Placed light (from placed torches): new colour, -20% brightness (*0.8)
    //   - Held light (from held items): new colour, -10% brightness (*0.9)
    // -------------------------------------------------------
    vec3 skyLightGamma  = texture(lightmap, vec2(0.0, adjustedLmcoord.y)).rgb;
    vec3 skyLightLinear = skyLightGamma * skyLightGamma;
    float bslBlockLight = clamp((adjustedLmcoord.x - 0.03125) * 1.06667, 0.0, 0.9333);
    float newLightmap   = pow(bslBlockLight, 5.0) * 2.0 + bslBlockLight * 1.0;
    float heldBoost     = max(0.0, adjustedLmcoord.x - lmcoord.x);
    bool  heldDominant  = (heldBoost > 0.001);
    float brightnessFactor = heldDominant ? 0.9 : 0.8;
    vec3 blockLighting  = blocklightCol * newLightmap * newLightmap * brightnessFactor;
    vec3 minLighting    = vec3(0.001) * (1.0 - lmcoord.y * lmcoord.y);
    vec3 albedoLinear   = albedo.rgb * albedo.rgb;
    vec3 lighting       = max(skyLightLinear + blockLighting + minLighting, vec3(0.0));
    vec3 finalLinear    = albedoLinear * lighting;
    color = vec4(sqrt(max(finalLinear, vec3(0.0))), albedo.a);

    // Wider reach, same peak, warm tint close to the source — same as
    // gbuffers_terrain.fsh. blockDominance ensures the boost only fires
    // where block light (lmcoord.x) is actually the stronger of the two
    // raw lightmap channels, so it no longer stacks on top of full sky
    // light (lmcoord.y) and blows out in daylight. See gbuffers_terrain.fsh
    // for the full rationale, including why only the ramp's low edge
    // moved (0.3 -> 0.05) — that extends the glow's reach and smooths
    // out its falloff without changing how bright it gets at the peak.
    // v1.2 — Natural distance falloff (same as gbuffers_terrain.fsh).
    // Replaced plateau'd smoothstep(0.05, 0.85, lmcoord.x) with
    // pow(lmcoord.x, 3.0) — preserves the peak at the source but
    // steepens the falloff so light dims naturally with distance.
    // See gbuffers_terrain.fsh for the full rationale and tuning
    // guide. Technique adapted from Complementary Reimagined's
    // block-light curve remapping.
    float blockDominance = smoothstep(0.0, 0.15, lmcoord.x - lmcoord.y);
    float emissiveBoost  = pow(lmcoord.x, 3.0) * blockDominance;
    color.rgb *= 1.0 + emissiveBoost * 1.6;

    const vec3 lightTint = vec3(1.0, 0.8, 0.55);
    color.rgb += lightTint * emissiveBoost * emissiveBoost * 0.45;

    normalOut = vec4(viewNormal * 0.5 + 0.5, 1.0);
    lightmapOut = vec4(lmcoord, 0.0, 1.0);  // .a = 1.0: pixel drawn (Iris requires this), .z = 0.0: not foliage/light
}
