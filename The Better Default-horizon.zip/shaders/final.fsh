#version 120

uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;
varying vec2 texcoord;

// ACES Tone Mapping
vec3 ACESFilm(vec3 x) {
    float a = 2.51;
    float b = 0.03;
    float c = 2.43;
    float d = 0.59;
    float e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

// FXAA Luma Calculation
float luma(vec3 color) {
    return dot(color, vec3(0.299, 0.587, 0.114));
}

// FXAA Implementation
vec3 applyFXAA(sampler2D tex, vec2 coords, vec2 resolution) {
    vec2 inverseRes = 1.0 / resolution;
    vec3 rgbM = texture2D(tex, coords).rgb;
    
    // Sampling neighbors
    vec3 rgbNW = texture2D(tex, coords + vec2(-1.0, -1.0) * inverseRes).rgb;
    vec3 rgbNE = texture2D(tex, coords + vec2(1.0, -1.0) * inverseRes).rgb;
    vec3 rgbSW = texture2D(tex, coords + vec2(-1.0, 1.0) * inverseRes).rgb;
    vec3 rgbSE = texture2D(tex, coords + vec2(1.0, 1.0) * inverseRes).rgb;
    
    vec3 lumaRecall = vec3(0.299, 0.587, 0.114);
    float lumaNW = dot(rgbNW, lumaRecall);
    float lumaNE = dot(rgbNE, lumaRecall);
    float lumaSW = dot(rgbSW, lumaRecall);
    float lumaSE = dot(rgbSE, lumaRecall);
    float lumaM  = dot(rgbM,  lumaRecall);
    
    float lumaMin = min(lumaM, min(min(lumaNW, lumaNE), min(lumaSW, lumaSE)));
    float lumaMax = max(lumaM, max(max(lumaNW, lumaNE), max(lumaSW, lumaSE)));
    
    vec2 dir;
    dir.x = -((lumaNW + lumaNE) - (lumaSW + lumaSE));
    dir.y =  ((lumaNW + lumaSW) - (lumaNE + lumaSE));
    
    float dirReduce = max((lumaNW + lumaNE + lumaSW + lumaSE) * (0.25 * 0.125), 0.0078125); 
    float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
    
    dir = min(vec2(8.0, 8.0), max(vec2(-8.0, -8.0), dir * rcpDirMin)) * inverseRes;
    
    vec3 rgbA = 0.5 * (
        texture2D(tex, coords + dir * (1.0 / 3.0 - 0.5)).rgb +
        texture2D(tex, coords + dir * (2.0 / 3.0 - 0.5)).rgb);
        
    vec3 rgbB = rgbA * 0.5 + 0.25 * (
        texture2D(tex, coords + dir * -0.5).rgb +
        texture2D(tex, coords + dir * 0.5).rgb);
        
    float lumaB = dot(rgbB, lumaRecall);
    
    if ((lumaB < lumaMin) || (lumaB > lumaMax)) {
        return rgbA;
    } else {
        return rgbB;
    }
}

void main() {
    // 1. apply FXAA as the very first read
    // Use uniforms. If viewWidth is 0 (unsupported), fallback to 1080p
    vec2 resolution = vec2(viewWidth, viewHeight);
    if (viewWidth < 1.0) resolution = vec2(1920.0, 1080.0);
    
    vec3 color = applyFXAA(colortex0, texcoord, resolution);
    
    // --- Soft Bloom ---
    vec3 bloomColor = vec3(0.0);
    // Tuned: Higher threshold so sand/snow doesn't glow under sun
    float threshold = 1.1; 
    
    vec2 pixelSize = 1.0 / resolution;
    float totalWeight = 0.0;
    
    // 9x9 Kernel
    float weights[5] = float[](0.227, 0.194, 0.121, 0.054, 0.016);
    
    for (float x = -3.0; x <= 3.0; x += 1.0) { 
        for (float y = -3.0; y <= 3.0; y += 1.0) {
            float dist = sqrt(x*x + y*y);
            if (dist > 3.0) continue;
            
            float weight = exp(-(dist*dist) / 4.0);
            
            vec2 offset = vec2(x, y) * pixelSize * 3.0; 
            vec3 sample = texture2D(colortex0, texcoord + offset).rgb;
            
            // Apply threshold
            sample = max(sample - vec3(threshold), vec3(0.0));
            
            bloomColor += sample * weight;
            totalWeight += weight;
        }
    }
    
    if (totalWeight > 0.0) bloomColor /= totalWeight;
    
    float bloomStrength = 0.6; 
    
    color += bloomColor * bloomStrength;
    
    // Exposure
    color *= 1.3;
    
    // Tone Mapping
    color = ACESFilm(color);
    
    gl_FragData[0] = vec4(color, 1.0);
}
