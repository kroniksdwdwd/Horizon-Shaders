#version 120

attribute vec4 mc_Entity;

uniform float frameTimeCounter;
uniform vec3 cameraPosition;

varying vec2 texcoord;
varying vec4 color;

// Shadow Distortion Logic 
vec4 distortShadow(vec4 pos) {
    vec3 v = pos.xyz / pos.w;
    // float dist = length(v.xy);
    float bias = 0.9; 
    float factor = (1.0 - bias) + length(v.xy) * bias;
    v.xy /= factor;
    return vec4(v, 1.0);
}

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    color = gl_Color;
    
    vec4 position = gl_Vertex;
    
    // --- Waving Logic (Must match terrain!) ---
    float entityId = mc_Entity.x;
    
    if (entityId > 10001.5 && entityId < 10007.5) { 
        float speed = 2.0;
        float magnitude = 0.05;
        
        if (abs(entityId - 10003.0) < 0.1 || abs(entityId - 10006.0) < 0.1) {
            magnitude = 0.04;
        } 
        
        if (abs(entityId - 10005.0) < 0.1 || abs(entityId - 10002.0) < 0.1 || abs(entityId - 10004.0) < 0.1) {
             magnitude = 0.1;
        }
        
        vec3 worldPos = position.xyz + cameraPosition;
        float offset = sin(frameTimeCounter * speed + worldPos.x * 0.5 + worldPos.z * 0.5 + worldPos.y);
        position.x += offset * magnitude;
    }
    
    vec4 viewPos = gl_ModelViewMatrix * position;
    vec4 clipPos = gl_ProjectionMatrix * viewPos;
    
    gl_Position = distortShadow(clipPos);
}
