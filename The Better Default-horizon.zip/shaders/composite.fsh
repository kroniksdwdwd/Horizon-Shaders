#version 120

uniform sampler2D colortex0; // Scene Color
uniform sampler2D colortex1; // Material Data (R=Spec, G=Rough)
uniform sampler2D depthtex0; // Depth Buffer

uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;

varying vec2 texcoord;

// Reconstruct View Space Position from Depth
vec3 getViewPos(vec2 uv, float depth) {
    vec4 clipPos = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 viewPos = gbufferProjectionInverse * clipPos;
    return viewPos.xyz / viewPos.w;
}

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;
    vec4 material = texture2D(colortex1, texcoord);
    float depth = texture2D(depthtex0, texcoord).r;
    
    // Decode Material
    float specStrength = material.r;
    float roughness = material.g;
    
    // --- Screen Space Reflections (SSR) ---
    // Only reflect if specular strength is high enough
    if (specStrength > 0.1 && depth < 1.0) {
        vec3 viewPos = getViewPos(texcoord, depth);
        vec3 normal = normalize(cross(dFdx(viewPos), dFdy(viewPos))); // Flat normal from depth
        
        // Reflection Vector
        vec3 viewDir = normalize(viewPos);
        vec3 reflectDir = reflect(viewDir, normal);
        
        // Raymarch
        vec3 rayPos = viewPos;
        vec3 rayDir = reflectDir;
        
        float stepSize = 0.2; // Step size in view space
        int maxSteps = 30; // Quality vs Perf
        
        vec3 hitColor = vec3(0.0);
        bool hit = false;
        
        // Jitter for roughness?
        
        for(int i=0; i<maxSteps; i++) {
            rayPos += rayDir * stepSize;
            
            // Project back to screen
            vec4 rayClip = gbufferProjection * vec4(rayPos, 1.0);
            vec3 rayNDC = rayClip.xyz / rayClip.w;
            
            if (abs(rayNDC.x) > 1.0 || abs(rayNDC.y) > 1.0 || rayNDC.z > 1.0 || rayNDC.z < -1.0) break; // Off screen
            
            vec2 rayScreen = rayNDC.xy * 0.5 + 0.5;
            float currentDepthBuffer = texture2D(depthtex0, rayScreen).r;
            
            // Linearize depth comparison?
            // Simple check: if ray depth > buffer depth, we hit something (maybe)
            // Need to convert buffer depth to view Z or vice versa.
            // Simplified: compare Clip Z (NDC Z) to Buffer NDC Z.
            
            // Buffer Depth is 0..1 (usually linear or log?? Iris usually standard GL depth)
            // Let's assume standard depth 0..1.
            
            float linearRayDepth = rayNDC.z * 0.5 + 0.5; // 0..1
            
            // Check intersection (with thickness)
            if (linearRayDepth > currentDepthBuffer && linearRayDepth < currentDepthBuffer + 0.01) {
                hit = true;
                hitColor = texture2D(colortex0, rayScreen).rgb;
                
                // Fade edges
                float edgeFade = 1.0 - max(abs(rayScreen.x - 0.5), abs(rayScreen.y - 0.5)) * 2.0;
                edgeFade = clamp(edgeFade * 5.0, 0.0, 1.0);
                
                // Reflectivity Fresnel
                float fresnel = 0.2 + 0.8 * pow(1.0 + dot(viewDir, normal), 5.0);
                
                color = mix(color, hitColor, specStrength * fresnel * edgeFade);
                break;
            }
            
            // Increase step size
             stepSize *= 1.1;
        }
    }
    
    gl_FragData[0] = vec4(color, 1.0);
    gl_FragData[1] = material; // Pass through material data if needed by composite1?
}
