#version 120

// Handheld Item Vertex Shader

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
#ifdef HZ_NFIX_normal
varying vec3 hz_nfix_in_normal; vec3 normal;
#else
varying vec3 normal;
#endif

void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
    lmcoord  = gl_MultiTexCoord1.xy / 240.0;
    
    // Normal for potential lighting (if we want dynamic hand light later)
    normal = gl_NormalMatrix * gl_Normal;
    
    color = gl_Color;
}
