#version 120
#define main hz_pack_main
#define HZ_NFIX_normal

attribute vec4 mc_Entity;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform float frameTimeCounter; // Animation time

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
#ifdef HZ_NFIX_normal
varying vec3 hz_nfix_in_normal; vec3 normal;
#else
varying vec3 normal;
#endif
varying vec3 viewPos;
varying vec4 shadowPos;
flat varying float blockId;

// Identifier from block.properties
// 10001=grass_block, 10002=tall_grass, 10003=leaves, 10004=grass/flowers, 10005=crops
// mc_Entity.x holds these IDs

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    color = gl_Color;
    normal = gl_NormalMatrix * gl_Normal;

    vec4 position = gl_Vertex;
    
    float entityId = mc_Entity.x;
    
    // Only wave specific plant IDs
    // 10002=tall_grass, 10003=leaves, 10004=flowers, 10005=crops, 10006=vine, 10007=lily_pad
    
    // Check if ID is one of our waving plants (IDs 10002 to 10007)
    if (entityId > 10001.5 && entityId < 10007.5) { 
        float speed = 2.0;
        float magnitude = 0.05;
        
        // Leaves (10003) & Vine (10006)
        if (abs(entityId - 10003.0) < 0.1 || abs(entityId - 10006.0) < 0.1) {
            magnitude = 0.04;
        } 
        
        // Crops (10005) & Grass/Flowers (10002, 10004)
        if (abs(entityId - 10005.0) < 0.1 || abs(entityId - 10002.0) < 0.1 || abs(entityId - 10004.0) < 0.1) {
             magnitude = 0.1;
             // Fix sliding by using floor of position for randomness (simulating integer block pos)
             // But for now, global wave is acceptable.
        }
        
        vec3 worldPos = position.xyz + cameraPosition;
        float offset = sin(frameTimeCounter * speed + worldPos.x * 0.5 + worldPos.z * 0.5 + worldPos.y);
        
        position.x += offset * magnitude;
    }

    gl_Position = gl_ModelViewMatrix * position;
    gl_Position = gl_ProjectionMatrix * gl_Position;
    
    // Shadow Coord Calculation
    // Use the potentially MODIFIED position for shadows! (So shadow waves too)
    // Use the potentially MODIFIED position for shadows! (So shadow waves too)
    vec4 viewPos4 = gl_ModelViewMatrix * position;
    viewPos = viewPos4.xyz;
    vec4 worldPosRel = gbufferModelViewInverse * viewPos4; 
    
    // --- Shadow Distortion ---
    vec4 shadowClip = shadowProjection * shadowModelView * worldPosRel;
    vec3 v = shadowClip.xyz / shadowClip.w;
    float bias = 0.9;
    float factor = (1.0 - bias) + length(v.xy) * bias;
    v.xy /= factor;
    
    shadowPos = vec4(v * 0.5 + 0.5, 1.0);
    
    // Pass Block ID to Fragment Shader
    blockId = mc_Entity.x;
}

// face-normals (horizon-shaderport)
#undef main
varying vec3 hz_nfix_vpos;
void main() {
    hz_pack_main();
    hz_nfix_in_normal = normal;
    hz_nfix_vpos = (gl_ModelViewMatrix * gl_Vertex).xyz;
}
