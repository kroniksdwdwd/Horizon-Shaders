#version 120
#define main hz_pack_main
#define HZ_NFIX_normal

uniform sampler2D texture;
uniform sampler2D shadow;
uniform vec3 sunPosition;
uniform int worldTime; // 0-24000
uniform int heldBlockLightValue; // 0-15
uniform int heldItemId; // Mapped from item.properties


// Iris/Sodium uniforms
uniform vec3 shadowLightPosition; 
uniform int isEyeInWater; // 0=None, 1=Water, 2=Lava 

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
#ifdef HZ_NFIX_normal
varying vec3 hz_nfix_in_normal; vec3 normal;
#else
varying vec3 normal;
#endif
varying vec3 viewPos;
varying vec4 shadowPos;
flat varying float blockId;

const int shadowMapResolution = 4096;

// Basic Bayer Pattern
const float dither4[4] = float[](
    0.0, 0.5,
    0.75, 0.25
);

// Declare Shadow Color Sampler
uniform sampler2D shadowcolor0;

vec3 getShadowColor(vec3 shadowPos) {
    if (shadowPos.x < 0.0 || shadowPos.x > 1.0 || 
        shadowPos.y < 0.0 || shadowPos.y > 1.0 || 
        shadowPos.z < 0.0 || shadowPos.z > 1.0) {
        return vec3(1.0);
    }

    float oneOverRes = 1.0 / float(shadowMapResolution);
    
    // Using center sample for color to save perf? Or PCF it too?
    // Let's do simple center sample for color first.
    vec4 blockerColor = texture2D(shadowcolor0, shadowPos.xy);
    
    // PCF Loop for Visibility
    float shadowVal = 0.0;
    float totalWeight = 0.0;
    
    // Standard Dither PCF
    float dither = dither4[int(mod(gl_FragCoord.x, 2.0)) + int(mod(gl_FragCoord.y, 2.0)) * 2];

    for (float x = -1.5; x <= 1.5; x += 1.0) {
        for (float y = -1.5; y <= 1.5; y += 1.0) {
            vec2 offset = vec2(x, y) * oneOverRes;
            offset += (vec2(dither) - 0.5) * oneOverRes * 0.5;
            
            float depth = texture2D(shadow, shadowPos.xy + offset).r;
            float bias = 0.0005; 
            
            if (depth < shadowPos.z - bias) {
                // In Shadow
                shadowVal += 0.0;
            } else {
                // Lit
                shadowVal += 1.0;
            }
            totalWeight += 1.0;
        }
    }
    
    float visibility = shadowVal / totalWeight;
    
    // If visible, return white.
    // If blocked (visibility < 1.0), check blocker color.
    // Note: blockerColor is from the shadow map position.
    // If blocker is transparent (alpha < 0.99), we transmit light.
    // Transmission = blockerColor.rgb; (Assuming texture color is the transmission color)
    // Opacity = blockerColor.a; (1.0 = opaque)
    
    // Logic: 
    // Final Light = Visibility * Sun + (1-Visibility) * TintedSun
    
    // Blocker Alpha Logic:
    // If opaque (a=1), tint is Black (0).
    // If glass (a=0.5, col=Red), tint is Redness.
    // Actually standard texture color for glass is the color itself.
    // We want to Multiply light by this color.
    
    vec3 shadowColorTint = vec3(0.0); // Default shadow is black
    if (blockerColor.a < 0.99) {
        // It's translucent!
        // Boost saturation/vibrancy
        // Square the color to make it richer? Or just multiply.
        // Let's remove the alpha usage to simply transmit PURE color if translucent.
        
        shadowColorTint = blockerColor.rgb; 
        
        // Artificial boost for "RTX" look
        // Make it slightly more saturated
        float gray = dot(shadowColorTint, vec3(0.33));
        shadowColorTint = mix(vec3(gray), shadowColorTint, 1.5); // 1.5x Saturation
    }
    
    return mix(shadowColorTint, vec3(1.0), visibility);
}

void main() {
    vec4 texColor = texture2D(texture, texcoord) * color;
    if (texColor.a < 0.5) discard; // Strict discard for cutout blocks (Grass) to remove "X" artifacts
    
    // Day/Night Calculation
    // worldTime: 0 = Sunrise, 6000 = Noon, 12000 = Sunset, 18000 = Midnight
    // Simple transition logic
    float time = float(worldTime);
    
    // Normalized Time (0..1) roughly centered on Noon
    // Actually simpler: check sunPosition.y
    // If sun is up (>0), it's day. If down, night.
    // Transition smoothly around 0.
    
    // Using sunPosition.y is robust for Iris
    // But sunPosition rotates -40 deg, so checks might be tricky.
    // Let's use simple worldTime ranges or just dot product of sun.
    
    // Let's use a simpler "dayFactor" based on worldTime for stability
    // Day: 0-12000, Night: 13000-23000
    // Smooth transition buffer
    
    float dayFactor = 1.0;
    if (worldTime > 12000 && worldTime < 13000) {
        // Sunset
        dayFactor = 1.0 - (float(worldTime) - 12000.0) / 1000.0;
    } else if (worldTime >= 13000 && worldTime <= 23000) {
        // Night
        dayFactor = 0.0;
    } else if (worldTime > 23000) {
        // Sunrise
        dayFactor = (float(worldTime) - 23000.0) / 1000.0;
    }
    
    // Colors
    vec3 daySunColor = vec3(1.0, 0.95, 0.85); 
    vec3 nightMoonColor = vec3(0.05, 0.1, 0.25) * 0.2; // Dim blue moonlight
    
    vec3 dayAmbient = vec3(0.4); 
    vec3 nightAmbient = vec3(0.05, 0.05, 0.1); 
    
    vec3 daySky = vec3(0.1, 0.2, 0.35);
    vec3 nightSky = vec3(0.01, 0.01, 0.02);

    // Current Values
    vec3 lightColor = mix(nightMoonColor, daySunColor, dayFactor);
    vec3 ambient = mix(nightAmbient, dayAmbient, dayFactor);
    vec3 skyMulti = mix(nightSky, daySky, dayFactor);
    
    // Direct Light
    vec3 lightDir = normalize(sunPosition);
    // At night, sun is down, so light comes from...? 
    // Usually shadow mapping follows "shadowLightPosition" which Iris updates to Moon at night.
    // But `sunPosition` might be under the earth.
    // Iris usually swaps shadowLightPosition to be the main light source.
    // Let's use `sunPosition` but flip it if night?
    // Actually, simple standard: use shadowLightPosition for direction if available, or just fallback.
    // But we stuck to sunPosition uniform.
    // If dayFactor < 0.1 (Night), light comes from Moon. 
    // Moon is roughly opposite sun.
    
    vec3 activeLightDir = lightDir;
    if (dayFactor < 0.5) {
        activeLightDir = -lightDir; // Approximate moon direction opposite sun
    }

    // --- Integrated PBR Logic ---
    float emissive = 0.0;
    float specularStrength = 0.0; // Default: Matte
    float roughness = 1.0;        // Default: Rough
    
    // ID Check
    // 10010 = Full Emissive (Torches, Lava)
    if (abs(blockId - 10010.0) < 0.1) {
        emissive = 1.0;
    }
    // 10013 = Activated Redstone
    if (abs(blockId - 10013.0) < 0.1) {
        emissive = 0.8; // Nice Red Glow
    }
    
    // 10020 = Metallic (Gold/Iron/Diamond blocks)
    // 10021 = Smooth (Ice/Glass)
    if (abs(blockId - 10020.0) < 0.1) {
        specularStrength = 1.0; // Strong reflection
        roughness = 0.2;        // Shiny
    }
    else if (abs(blockId - 10021.0) < 0.1) {
        specularStrength = 0.8;
        roughness = 0.05;       // Very Smooth (Ice)
    }
    
    // --- Double Sided Lighting Fix ---
    // Foliage (Cross models) often has normals pointing one way.
    // If we look from behind, NdotL is negative and it looks black (or weird with shadow).
    // For foliage (ID 10004/10002/10005), we should flip normal if back-facing.
    
    vec3 adjNormal = normal;
    if (blockId > 10001.5 && blockId < 10005.5) { // Foliage IDs
         if (dot(adjNormal, viewPos) > 0.0) adjNormal = -adjNormal; // Flip if facing away? 
         // Actually gl_FrontFacing is better but standard shaders usually use a trick.
         // Let's just use abs(NdotL) for foliage to simulate translucency.
    }

    float NdotL = max(dot(normalize(adjNormal), activeLightDir), 0.0);
    // For grass/leaves, allow light from behind (translucency)
    if (blockId > 10001.5 && blockId < 10005.5) {
        NdotL = mix(NdotL, 1.0, 0.3); // Fake subsurface scattering
    }
    
    // Shadow Calculation
    vec3 shadowFactor = vec3(1.0);
    if (NdotL > 0.0) {
        shadowFactor = getShadowColor(shadowPos.xyz);
    }
    
    // Mask Sunlight by Skylight Data
    float sunVisibility = smoothstep(0.05, 1.0, lmcoord.y);
    
    vec3 diffuse = lightColor * NdotL * shadowFactor * sunVisibility;
    
    // --- Dynamic Lighting (Handheld) ---
    float handheldLight = 0.0;
    vec3 handheldColor = vec3(1.0, 0.6, 0.4); // Default Orange
    
    if (heldBlockLightValue > 0) {
        // Distance Falloff
        float dist = length(viewPos);
        float lightRange = float(heldBlockLightValue) * 1.5; 
        handheldLight = max(0.0, 1.0 - dist / lightRange);
        
        // Color Selection based on heldItemId
        if (heldItemId == 2) {
            // Soul = Blue/Cyan
            handheldColor = vec3(0.4, 0.8, 1.0);
        } else if (heldItemId == 3) {
            // Redstone = Red
            handheldColor = vec3(1.0, 0.2, 0.1);
        } else if (heldItemId == 4) {
            // Sea/End/Verdant = White/Greenish
            handheldColor = vec3(0.8, 1.0, 0.9);
        } else if (heldItemId == 5) {
            // Amethyst = Purple
            handheldColor = vec3(0.8, 0.4, 1.0);
        }
    }
    
    // --- Torch Flicker ---
    float flicker = 1.0 + 0.05 * sin(float(worldTime) * 0.3) + 0.02 * sin(float(worldTime) * 1.3);
    
    // Block Light Logic
    // We have "placed" block light (always orange map) and "handheld" light (colored).
    // We need to add them carefully.
    
    // Existing placed light (from map) assumed Orange-ish
    vec3 placedLightColor = vec3(1.0, 0.6, 0.4); 
    
    // Combine
    vec3 combinedBlockLight = placedLightColor * lmcoord.x + handheldColor * handheldLight;
    
    // Apply flicker to all for liveness
    vec3 blockLight = combinedBlockLight * flicker;
    
    vec3 skylight = skyMulti * lmcoord.y;
    
    // Modulate ambient by skylight (lmcoord.y)
    vec3 effectiveAmbient = ambient * (lmcoord.y * lmcoord.y + 0.002); 
    
    vec3 finalLight = effectiveAmbient + diffuse + blockLight + skylight;
    
    // Apply Emissive Override
    // 10010 = Standard Orange-ish Brightness
    if (abs(blockId - 10010.0) < 0.1) {
        finalLight = max(finalLight, vec3(1.2)); 
    }
    // 10013 = Redstone (Red)
    else if (abs(blockId - 10013.0) < 0.1) {
        finalLight = max(finalLight, vec3(1.0)); 
        // We will tint the texture in FinalColor step or just rely on texture color?
        // Redstone dust is already red. Torches are red.
        // Let's boost Red channel slightly to ensure it glows RED.
    }
    // 10014 = Soul (Blue)
    else if (abs(blockId - 10014.0) < 0.1) {
        finalLight = max(finalLight, vec3(1.5)); // Bright
    }
    // 10015 = Sea (White/Cyan)
    else if (abs(blockId - 10015.0) < 0.1) {
         finalLight = max(finalLight, vec3(1.3));
    }
    
    vec3 finalColor = texColor.rgb * finalLight;
    
    // Tinting Logic for "Glow"
    if (abs(blockId - 10013.0) < 0.1) { // Redstone
        finalColor *= vec3(1.2, 0.8, 0.8); // Red tint
    }
    else if (abs(blockId - 10014.0) < 0.1) { // Soul
        finalColor *= vec3(0.6, 0.9, 1.5); // Blue tint boost
    }
    else if (abs(blockId - 10015.0) < 0.1) { // Sea
        finalColor *= vec3(0.9, 1.2, 1.1); // Cyan-ish
    }
    
    // Specular Add
    if (specularStrength > 0.0) {
        // ... (Specular code) ...
         vec3 viewDir = normalize(-viewPos);
         vec3 lightDir = normalize(sunPosition);
         vec3 halfVector = normalize(lightDir + viewDir);
         float NdotH = max(dot(normalize(adjNormal), halfVector), 0.0); // Use adjNormal
         float shininess = (1.0 - roughness) * 128.0;
         vec3 specular = pow(NdotH, shininess) * shadowFactor * specularStrength;
         finalColor += specular;
    }

    // --- Fog Application ---
    // uniform int isEyeInWater; (Need to declare)
    // 0=None, 1=Water, 2=Lava
    
    float depth = gl_FragCoord.z / gl_FragCoord.w; // View Space Depth (approx distance)
    float fogDensity = 0.0;
    vec3 fogColor = vec3(0.0);
    
    if (isEyeInWater == 1) {
        // Underwater Fog
        fogDensity = 0.15; // Dense
        fogColor = vec3(0.1, 0.4, 0.6) * (lmcoord.y * 0.8 + 0.2); // Tints with skylight
    } else if (isEyeInWater == 2) {
        // Lava Fog
        fogDensity = 0.5;
        fogColor = vec3(1.0, 0.4, 0.0);
    } else {
        // Atmosphere Fog
        // fogDensity = 0.005; 
        // fogColor = skyMulti; // Fade to sky
        // Disable regular fog for now to keep it clear? Or slight?
        fogDensity = 0.001; 
        fogColor = clamp(skyMulti, 0.0, 1.0);
    }
    
    float fogFactor = 1.0 - exp(-depth * fogDensity);
    fogFactor = clamp(fogFactor, 0.0, 1.0);
    
    finalColor = mix(finalColor, fogColor, fogFactor);

    gl_FragData[0] = vec4(finalColor, texColor.a);
    
    // Write Material Data to colortex1
    // R = Specular Strength
    // G = Roughness
    // B = Emissive (optional)
    // A = 1.0
    gl_FragData[1] = vec4(specularStrength, roughness, emissive, 1.0);
}

// face-normals (horizon-shaderport)
#undef main
varying vec3 hz_nfix_vpos;
mat3 hz_nfix_rw;
mat3 hz_nfix_rv;
void hz_nfix_frame() {
    vec3 hz_n = cross(dFdx(hz_nfix_vpos), dFdy(hz_nfix_vpos));
    hz_n = dot(hz_n, hz_n) > 1e-24 ? normalize(hz_n) : vec3(0.0, 0.0, 1.0);
    if (dot(hz_n, hz_nfix_vpos) > 0.0) hz_n = -hz_n;
    mat3 hz_v = mat3(gl_ModelViewMatrix);
    vec3 hz_w = transpose(hz_v) * hz_n;
    vec3 hz_a = abs(hz_w);
    float hz_m = max(hz_a.x, max(hz_a.y, hz_a.z));
    if (hz_m > 0.97) hz_w = step(vec3(hz_m), hz_a) * sign(hz_w);
    hz_w = normalize(hz_w);
    vec3 hz_t = abs(hz_w.y) > 0.9 ? vec3(1.0, 0.0, 0.0) : normalize(cross(vec3(0.0, 1.0, 0.0), hz_w));
    hz_nfix_rw = mat3(hz_t, hz_w, cross(hz_t, hz_w));
    hz_nfix_rv = hz_v * hz_nfix_rw * transpose(hz_v);
}
void main() {
    hz_nfix_frame();
    normal = hz_nfix_rv * hz_nfix_in_normal;
    hz_pack_main();
}
