#version 120

uniform sampler2D texture;
uniform sampler2D shadow;
uniform sampler2D shadowcolor0;
uniform int heldBlockLightValue;
uniform int heldItemId;

uniform vec3 sunPosition;
uniform int worldTime;
uniform int isEyeInWater; // 0=None, 1=Water, 2=Lava

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
#ifdef HZ_NFIX_normal
varying vec3 hz_nfix_in_normal; vec3 normal;
#else
varying vec3 normal;
#endif
varying vec3 viewPos;
varying vec4 shadowPos;

const int shadowMapResolution = 4096;

// Reuse Shadow Logic
vec3 getShadowColor(vec3 shadowPos) {
    if (shadowPos.x < 0.0 || shadowPos.x > 1.0 || 
        shadowPos.y < 0.0 || shadowPos.y > 1.0 || 
        shadowPos.z < 0.0 || shadowPos.z > 1.0) {
        return vec3(1.0);
    }

    float oneOverRes = 1.0 / float(shadowMapResolution);
    vec4 blockerColor = texture2D(shadowcolor0, shadowPos.xy);
    
    float shadowVal = 0.0;
    float totalWeight = 0.0;
    
    // Simple 2x2 PCF
    for (float x = -0.5; x <= 0.5; x += 1.0) {
        for (float y = -0.5; y <= 0.5; y += 1.0) {
            float depth = texture2D(shadow, shadowPos.xy + vec2(x, y) * oneOverRes).r;
            if (depth < shadowPos.z - 0.0005) {
                shadowVal += 0.0;
            } else {
                shadowVal += 1.0;
            }
            totalWeight += 1.0;
        }
    }
    
    float visibility = shadowVal / totalWeight;
    
    vec3 shadowColorTint = vec3(0.0);
    if (blockerColor.a < 0.99) {
        shadowColorTint = blockerColor.rgb; 
        float gray = dot(shadowColorTint, vec3(0.33));
        shadowColorTint = mix(vec3(gray), shadowColorTint, 1.5);
    }
    
    return mix(shadowColorTint, vec3(1.0), visibility);
}

void main() {
    vec4 texColor = texture2D(texture, texcoord) * color;
    if (texColor.a < 0.1) discard;
    
    // Day/Night Logic (Simplified)
    float dayFactor = 1.0;
    if (worldTime > 12000 && worldTime < 13000) dayFactor = 1.0 - (float(worldTime) - 12000.0) / 1000.0;
    else if (worldTime >= 13000 && worldTime <= 23000) dayFactor = 0.0;
    else if (worldTime > 23000) dayFactor = (float(worldTime) - 23000.0) / 1000.0;
    
    vec3 daySunColor = vec3(1.0, 0.95, 0.85); 
    vec3 nightMoonColor = vec3(0.05, 0.1, 0.25) * 0.2; 
    vec3 lightColor = mix(nightMoonColor, daySunColor, dayFactor);
    
    vec3 ambient = mix(vec3(0.05, 0.05, 0.1), vec3(0.4), dayFactor);
    vec3 skyMulti = mix(vec3(0.01, 0.01, 0.02), vec3(0.1, 0.2, 0.35), dayFactor);

    vec3 lightDir = normalize(sunPosition);
    vec3 activeLightDir = lightDir;
    if (dayFactor < 0.5) activeLightDir = -lightDir;

    // Lighting
    float NdotL = max(dot(normalize(normal), activeLightDir), 0.0);
    
    // Mix NdotL for mobs (subsurface?)
    // Many mobs look better with soft lighting
    NdotL = mix(NdotL, 1.0, 0.2); 
    
    vec3 shadowFactor = vec3(1.0);
    if (NdotL > 0.0) {
        shadowFactor = getShadowColor(shadowPos.xyz);
    }
    
    float sunVisibility = smoothstep(0.05, 1.0, lmcoord.y);
    vec3 diffuse = lightColor * NdotL * shadowFactor * sunVisibility;
    
    // --- Dynamic Lighting (Handheld) ---
    float handheldLight = 0.0;
    vec3 handheldColor = vec3(1.0, 0.6, 0.4);
    
    if (heldBlockLightValue > 0) {
        float dist = length(viewPos);
        float lightRange = float(heldBlockLightValue) * 1.5; 
        handheldLight = max(0.0, 1.0 - dist / lightRange);
        
        if (heldItemId == 2) handheldColor = vec3(0.4, 0.8, 1.0);
        else if (heldItemId == 3) handheldColor = vec3(1.0, 0.2, 0.1);
        else if (heldItemId == 4) handheldColor = vec3(0.8, 1.0, 0.9);
        else if (heldItemId == 5) handheldColor = vec3(0.8, 0.4, 1.0);
    }
    float flicker = 1.0 + 0.05 * sin(float(worldTime) * 0.3) + 0.02 * sin(float(worldTime) * 1.3);
    
    vec3 placedLightColor = vec3(1.0, 0.6, 0.4); 
    vec3 combinedBlockLight = placedLightColor * lmcoord.x + handheldColor * handheldLight;

    vec3 blockLight = combinedBlockLight * flicker;
    vec3 skylight = skyMulti * lmcoord.y;
    vec3 effectiveAmbient = ambient * (lmcoord.y * lmcoord.y + 0.002);
    
    vec3 finalLight = effectiveAmbient + diffuse + blockLight + skylight;
    
    // Emissive Mobs? (Glow Squid, Blaze, etc)
    // We can check texture brightness or use ID if available (mc_Entity.x)
    // But entities don't always pass reliable IDs in standard packs without config.
    // For now, simple standard lighting.
    
    // Glow Squid Brightness Hack
    // If texture is very bright in dark?
    // Difficult without ID.
    
    vec3 finalColor = texColor.rgb * finalLight;
    
    // --- Fog ---
    float depth = gl_FragCoord.z / gl_FragCoord.w; 
    float fogDensity = 0.0;
    vec3 fogColor = vec3(0.0);
    
    if (isEyeInWater == 1) {
        fogDensity = 0.15; 
        fogColor = vec3(0.1, 0.4, 0.6) * (lmcoord.y * 0.8 + 0.2); 
    } else if (isEyeInWater == 2) {
        fogDensity = 0.5;
        fogColor = vec3(1.0, 0.4, 0.0);
    } else {
         fogDensity = 0.001; 
         fogColor = clamp(skyMulti, 0.0, 1.0);
    }
    
    float fogFactor = 1.0 - exp(-depth * fogDensity);
    fogFactor = clamp(fogFactor, 0.0, 1.0);
    
    finalColor = mix(finalColor, fogColor, fogFactor);
    
    gl_FragData[0] = vec4(finalColor, texColor.a);
    
    // Entities Material -> Matte
    gl_FragData[1] = vec4(0.0, 1.0, 0.0, 1.0);
}
