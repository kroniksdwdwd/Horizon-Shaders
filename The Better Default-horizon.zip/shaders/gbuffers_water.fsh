#version 120
#define main hz_pack_main
#define HZ_NFIX_normal

uniform sampler2D texture;
uniform sampler2D shadow;
uniform vec3 sunPosition;
uniform vec3 cameraPosition;
uniform int worldTime;
uniform int heldBlockLightValue;
uniform int heldItemId;
uniform int isEyeInWater; // 0=None, 1=Water, 2=Lava

varying vec3 viewPos; 
varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
#ifdef HZ_NFIX_normal
varying vec3 hz_nfix_in_normal; vec3 normal;
#else
varying vec3 normal;
#endif
varying vec4 shadowPos;

const int shadowMapResolution = 4096;

float getShadow(vec3 shadowPos) {
    if (shadowPos.x < 0.0 || shadowPos.x > 1.0 || 
        shadowPos.y < 0.0 || shadowPos.y > 1.0 || 
        shadowPos.z < 0.0 || shadowPos.z > 1.0) {
        return 1.0;
    }

    float oneOverRes = 1.0 / float(shadowMapResolution);
    float shadowVal = 0.0;
    float totalWeight = 0.0;

    // Simple PCF 
    for (float x = -0.5; x <= 0.5; x += 1.0) {
        for (float y = -0.5; y <= 0.5; y += 1.0) {
            float depth = texture2D(shadow, shadowPos.xy + vec2(x, y) * oneOverRes).r;
            if (depth < shadowPos.z - 0.0005) {
                shadowVal += 0.0;
            } else {
                shadowVal += 1.0;
            }
            totalWeight += 1.0;
        }
    }
    return shadowVal / totalWeight;
}

void main() {
    vec4 texColor = texture2D(texture, texcoord) * color;
    
    // Day/Night Factor
    // Day: 0-12000, Night: 13000-23000
    float dayFactor = 1.0;
    if (worldTime > 12000 && worldTime < 13000) {
        dayFactor = 1.0 - (float(worldTime) - 12000.0) / 1000.0;
    } else if (worldTime >= 13000 && worldTime <= 23000) {
        dayFactor = 0.0;
    } else if (worldTime > 23000) {
        dayFactor = (float(worldTime) - 23000.0) / 1000.0;
    }

    // Colors
    vec3 daySunColor = vec3(1.0, 0.95, 0.85); 
    vec3 nightMoonColor = vec3(0.05, 0.1, 0.25) * 0.2; 
    
    vec3 dayAmbient = vec3(0.4); 
    vec3 nightAmbient = vec3(0.05, 0.05, 0.1); 
    
    vec3 daySky = vec3(0.1, 0.2, 0.35);
    vec3 nightSky = vec3(0.01, 0.01, 0.02);

    vec3 lightColor = mix(nightMoonColor, daySunColor, dayFactor);
    vec3 ambient = mix(nightAmbient, dayAmbient, dayFactor);
    vec3 skyMulti = mix(nightSky, daySky, dayFactor);
    
    // Lighting
    vec3 lightDir = normalize(sunPosition);
    vec3 activeLightDir = lightDir;
    if (dayFactor < 0.5) {
        activeLightDir = -lightDir; 
    }

    vec3 norm = normalize(normal);
    float NdotL = max(dot(norm, activeLightDir), 0.0);
    
    float shadowFactor = 1.0;
    if (NdotL > 0.0) {
        shadowFactor = getShadow(shadowPos.xyz);
    }
    
    // Reduce shadow strength at night to be barely visible/soft?
    // For now, keep math consistent.
    
    // Mask Sunlight by Skylight Data
    float sunVisibility = smoothstep(0.05, 1.0, lmcoord.y);
    vec3 diffuse = lightColor * NdotL * shadowFactor * sunVisibility;
    
    // --- Dynamic Lighting (Handheld) ---
    float handheldLight = 0.0;
    vec3 handheldColor = vec3(1.0, 0.6, 0.4);
    
    if (heldBlockLightValue > 0) {
        float dist = length(viewPos);
        float lightRange = float(heldBlockLightValue) * 1.5; 
        handheldLight = max(0.0, 1.0 - dist / lightRange);
        
        if (heldItemId == 2) handheldColor = vec3(0.4, 0.8, 1.0);
        else if (heldItemId == 3) handheldColor = vec3(1.0, 0.2, 0.1);
        else if (heldItemId == 4) handheldColor = vec3(0.8, 1.0, 0.9);
        else if (heldItemId == 5) handheldColor = vec3(0.8, 0.4, 1.0);
    }
    float flicker = 1.0 + 0.05 * sin(float(worldTime) * 0.3) + 0.02 * sin(float(worldTime) * 1.3);
    
    vec3 placedLightColor = vec3(1.0, 0.6, 0.4); 
    vec3 combinedBlockLight = placedLightColor * lmcoord.x + handheldColor * handheldLight;

    vec3 blockLight = combinedBlockLight * flicker;
    vec3 skylight = skyMulti * lmcoord.y;
    
    // Specular Highlight (Blinn-Phong)
    // Reduce specular at night (moon reflection is weaker)
    float specStrength = dayFactor * 0.8 + (1.0 - dayFactor) * 0.1; // Dimmer moon reflection
    
    vec3 viewDir = normalize(-viewPos); 
    vec3 halfVector = normalize(activeLightDir + viewDir);
    float NdotH = max(dot(norm, halfVector), 0.0);
    float specular = pow(NdotH, 64.0) * shadowFactor; 
    
    vec3 specColor = vec3(1.0) * specular * specStrength;

    // Ambient Occlusion / Skylight dependance
    // Water in caves should be dark
    vec3 effectiveAmbient = ambient * (lmcoord.y * lmcoord.y + 0.05); // Water slightly brighter/reflective?

    vec3 finalLight = effectiveAmbient + diffuse + blockLight + skylight;
    
    vec3 finalColor = texColor.rgb * finalLight + specColor;
    
    // --- Fog Application ---
    float depth = gl_FragCoord.z / gl_FragCoord.w; 
    float fogDensity = 0.0;
    vec3 fogColor = vec3(0.0);
    
    if (isEyeInWater == 1) {
        fogDensity = 0.15; 
        fogColor = vec3(0.1, 0.4, 0.6) * (lmcoord.y * 0.8 + 0.2); 
    } else if (isEyeInWater == 2) {
        fogDensity = 0.5;
        fogColor = vec3(1.0, 0.4, 0.0);
    } else {
        fogDensity = 0.001; 
        fogColor = clamp(skyMulti, 0.0, 1.0);
    }
    
    float fogFactor = 1.0 - exp(-depth * fogDensity);
    fogFactor = clamp(fogFactor, 0.0, 1.0);
    
    finalColor = mix(finalColor, fogColor, fogFactor);

    gl_FragData[0] = vec4(finalColor, texColor.a);
    
    // Water Material
    // Specular = 1.0 (Very reflective)
    // Roughness = 0.02 (Very smooth)
    gl_FragData[1] = vec4(1.0, 0.02, 0.0, 1.0);
}

// face-normals (horizon-shaderport)
#undef main
varying vec3 hz_nfix_vpos;
mat3 hz_nfix_rw;
mat3 hz_nfix_rv;
void hz_nfix_frame() {
    vec3 hz_n = cross(dFdx(hz_nfix_vpos), dFdy(hz_nfix_vpos));
    hz_n = dot(hz_n, hz_n) > 1e-24 ? normalize(hz_n) : vec3(0.0, 0.0, 1.0);
    if (dot(hz_n, hz_nfix_vpos) > 0.0) hz_n = -hz_n;
    mat3 hz_v = mat3(gl_ModelViewMatrix);
    vec3 hz_w = transpose(hz_v) * hz_n;
    vec3 hz_a = abs(hz_w);
    float hz_m = max(hz_a.x, max(hz_a.y, hz_a.z));
    if (hz_m > 0.97) hz_w = step(vec3(hz_m), hz_a) * sign(hz_w);
    hz_w = normalize(hz_w);
    vec3 hz_t = abs(hz_w.y) > 0.9 ? vec3(1.0, 0.0, 0.0) : normalize(cross(vec3(0.0, 1.0, 0.0), hz_w));
    hz_nfix_rw = mat3(hz_t, hz_w, cross(hz_t, hz_w));
    hz_nfix_rv = hz_v * hz_nfix_rw * transpose(hz_v);
}
void main() {
    hz_nfix_frame();
    normal = hz_nfix_rv * hz_nfix_in_normal;
    hz_pack_main();
}
