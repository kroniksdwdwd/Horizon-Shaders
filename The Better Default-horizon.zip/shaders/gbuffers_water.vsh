#version 120
#define main hz_pack_main
#define HZ_NFIX_normal

attribute vec4 mc_Entity;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
#ifdef HZ_NFIX_normal
varying vec3 hz_nfix_in_normal; vec3 normal;
#else
varying vec3 normal;
#endif
varying vec3 viewPos;
varying vec4 shadowPos;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    color = gl_Color;
    // normal = gl_NormalMatrix * gl_Normal;
    normal = normalize(gl_NormalMatrix * gl_Normal); // Normalize just in case

    vec4 viewPos4 = gl_ModelViewMatrix * gl_Vertex;
    viewPos = viewPos4.xyz;
    gl_Position = gl_ProjectionMatrix * viewPos4;
    
    // Shadow Coord Calculation
    vec4 worldPosRel = gbufferModelViewInverse * vec4(viewPos, 1.0); 
    
    // --- Shadow Distortion ---
    vec4 shadowClip = shadowProjection * shadowModelView * worldPosRel;
    vec3 v = shadowClip.xyz / shadowClip.w;
    float bias = 0.9;
    float factor = (1.0 - bias) + length(v.xy) * bias;
    v.xy /= factor;
    
    shadowPos = vec4(v * 0.5 + 0.5, 1.0);
}

// face-normals (horizon-shaderport)
#undef main
varying vec3 hz_nfix_vpos;
void main() {
    hz_pack_main();
    hz_nfix_in_normal = normal;
    hz_nfix_vpos = (gl_ModelViewMatrix * gl_Vertex).xyz;
}
