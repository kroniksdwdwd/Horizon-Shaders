#version 120

uniform sampler2D texture;
uniform int worldTime;

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;

void main() {
    vec4 texColor = texture2D(texture, texcoord) * color;
    
    // Apply Lightmap (Block Light + Sky Light)
    // Handheld items should respond to light!
    // Vanilla usually does this via gl_Color but using lightmap explicitly is safer for shaders
    // Actually gl_Color usually contains the lightmap modulation in Fixed Function, but we want control.
    
    // Simple Lighting Multiplier
    // torch light (x) + sky light (y)
    vec3 lightMapColor = mix(vec3(0.05), vec3(1.0), lmcoord.x); // Block light
    vec3 skyLightColor = mix(vec3(0.05), vec3(1.0), lmcoord.y); // Sky light
    
    // Use max of both?
    vec3 lighting = max(lightMapColor, skyLightColor);
    
    // If night, skyLightColor is dark?
    // We rely on standard shader props.
    // Actually, simplifying: just use generic "mult" if available? 
    // In gbuffers_hand, typically we just multiply by color if we want vanilla look.
    // BUT user complained about "brightness".
    // If "color" is 1.0 (white), and we don't multiply by darkness, it glows.
    
    // Apply standard lightmap multiplication
    // Use texture(lightmap) if available? 
    // Let's manually simulate standard light.
    
    vec3 blockLight = vec3(1.0, 0.9, 0.8) * lmcoord.x;
    vec3 skyLight   = vec3(0.9, 0.9, 1.0) * lmcoord.y;
    vec3 mixedLight = max(blockLight, skyLight);
    
    // Ensure minimum ambient so hand isn't pitch black
    mixedLight = max(mixedLight, vec3(0.1));
    
    gl_FragData[0] = vec4(texColor.rgb * mixedLight, texColor.a);
    
    // Fix MRT - Write Matte Material (No Specular)
    gl_FragData[1] = vec4(0.0, 1.0, 0.0, 1.0);
}
