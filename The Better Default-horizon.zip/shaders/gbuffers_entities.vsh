#version 120

// Basic Entity Vertex Shader
// Compatible with Iris/Optifine

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
#ifdef HZ_NFIX_normal
varying vec3 hz_nfix_in_normal; vec3 normal;
#else
varying vec3 normal;
#endif
varying vec3 viewPos;
varying vec4 shadowPos;

// Uniforms
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferModelView;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 sunPosition;

// Distortion for Shadows
vec4 distortShadow(vec4 shadowPos) {
    vec3 v = shadowPos.xyz / shadowPos.w;
    float dist = length(v.xy);
    float distortion = 1.0 + dist * 0.2 + dist * dist * 0.1; // Simple distortion
    v.xy /= distortion;
    return vec4(v, 1.0);
}

void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
    
    // Entity Color (e.g. Sheep color, damage red)
    color = gl_Color;
    
    // Lightmap Coordinates
    lmcoord = gl_MultiTexCoord1.xy / 240.0; // Normalize 0..1
    
    // Normal
    normal = gl_NormalMatrix * gl_Normal;
    
    // View Position
    vec4 viewPos4 = gl_ModelViewMatrix * gl_Vertex;
    viewPos = viewPos4.xyz;
    
    // Shadow Position
    // We need world space to standard shadow mapping
    // But entities move?
    // Iris handles this if we use gbufferModelViewInverse properly.
    
    vec4 worldPos = gbufferModelViewInverse * viewPos4;
    vec4 shadowClip = shadowProjection * shadowModelView * worldPos;
    shadowPos = distortShadow(shadowClip);
    
    // Convert to 0..1 range
    shadowPos.xyz = shadowPos.xyz * 0.5 + 0.5;
}
