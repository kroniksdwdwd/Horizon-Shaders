#version 120

uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 color;

void main() {
    vec4 texColor = texture2D(texture, texcoord) * color;
    
    // Alpha Test (keep transparents for colored shadows?)
    // If we want colored shadows, we MUST process transparent things.
    // Usually we discard very low alpha, but keep stained glass (alpha ~0.3-0.5).
    if (texColor.a < 0.1) discard; 
    
    // Write color to shadowcolor0
    // Standard opaque blocks write their color (often dark/opaque).
    // Translucent glass writes its color + alpha.
    gl_FragData[0] = texColor;
}
