/* 
BSL Shaders v8 Series by Capt Tatsu 
https://bitslablab.com 
*/ 

#version 120 
// horizon-shaderport noise-2d: the game loads no noise texture; built from the pack's image
#ifndef HZ_TEX2N
#define HZ_TEX2N
// noisetex is a bvec3: no other stand-in overloads that type (naga takes two struct types as one)
#ifndef HZ_T3_NOISE
#define HZ_T3_NOISE
float hz_t3_hash(vec3 p) { p = fract(p * 0.1031); p += dot(p, p.zyx + 31.32); return fract((p.x + p.y) * p.z); }
float hz_t3_noise(vec3 p, float n, float seed) {
    vec3 q = p * n; vec3 i = floor(q); vec3 f = q - i; f = f * f * (3.0 - 2.0 * f);
    vec3 a = i - n * floor(i / n) + seed; vec3 b = (i + 1.0) - n * floor((i + 1.0) / n) + seed;
    return mix(mix(mix(hz_t3_hash(vec3(a.x, a.y, a.z)), hz_t3_hash(vec3(b.x, a.y, a.z)), f.x),
                   mix(hz_t3_hash(vec3(a.x, b.y, a.z)), hz_t3_hash(vec3(b.x, b.y, a.z)), f.x), f.y),
               mix(mix(hz_t3_hash(vec3(a.x, a.y, b.z)), hz_t3_hash(vec3(b.x, a.y, b.z)), f.x),
                   mix(hz_t3_hash(vec3(a.x, b.y, b.z)), hz_t3_hash(vec3(b.x, b.y, b.z)), f.x), f.y), f.z);
}
#endif
// tex/noise.png 512x512: r smooth (51 cells), g smooth (31 cells), b white, a white
float hz_n2_q0(float x) {
    if (x <= 0.166118) return mix(0.074510, 0.321569, clamp((x - 0.004531) / 0.161587, 0.0, 1.0));
    if (x <= 0.234020) return mix(0.321569, 0.360784, clamp((x - 0.166118) / 0.067902, 0.0, 1.0));
    if (x <= 0.287146) return mix(0.360784, 0.392157, clamp((x - 0.234020) / 0.053125, 0.0, 1.0));
    if (x <= 0.334622) return mix(0.392157, 0.415686, clamp((x - 0.287146) / 0.047476, 0.0, 1.0));
    if (x <= 0.379875) return mix(0.415686, 0.435294, clamp((x - 0.334622) / 0.045253, 0.0, 1.0));
    if (x <= 0.419621) return mix(0.435294, 0.454902, clamp((x - 0.379875) / 0.039746, 0.0, 1.0));
    if (x <= 0.460037) return mix(0.454902, 0.470588, clamp((x - 0.419621) / 0.040416, 0.0, 1.0));
    if (x <= 0.500516) return mix(0.470588, 0.486275, clamp((x - 0.460037) / 0.040479, 0.0, 1.0));
    if (x <= 0.538476) return mix(0.486275, 0.501961, clamp((x - 0.500516) / 0.037959, 0.0, 1.0));
    if (x <= 0.579402) return mix(0.501961, 0.517647, clamp((x - 0.538476) / 0.040927, 0.0, 1.0));
    if (x <= 0.622019) return mix(0.517647, 0.533333, clamp((x - 0.579402) / 0.042616, 0.0, 1.0));
    if (x <= 0.664950) return mix(0.533333, 0.552941, clamp((x - 0.622019) / 0.042932, 0.0, 1.0));
    if (x <= 0.711636) return mix(0.552941, 0.572549, clamp((x - 0.664950) / 0.046685, 0.0, 1.0));
    if (x <= 0.767029) return mix(0.572549, 0.596078, clamp((x - 0.711636) / 0.055393, 0.0, 1.0));
    if (x <= 0.836535) return mix(0.596078, 0.623529, clamp((x - 0.767029) / 0.069506, 0.0, 1.0));
    if (x <= 0.996197) return mix(0.623529, 0.709804, clamp((x - 0.836535) / 0.159662, 0.0, 1.0));
    return 0.709804;
}
float hz_n2_q1(float x) {
    if (x <= 0.168916) return mix(0.007843, 0.121569, clamp((x - 0.003332) / 0.165583, 0.0, 1.0));
    if (x <= 0.242485) return mix(0.121569, 0.152941, clamp((x - 0.168916) / 0.073569, 0.0, 1.0));
    if (x <= 0.296349) return mix(0.152941, 0.176471, clamp((x - 0.242485) / 0.053864, 0.0, 1.0));
    if (x <= 0.343263) return mix(0.176471, 0.196078, clamp((x - 0.296349) / 0.046914, 0.0, 1.0));
    if (x <= 0.386970) return mix(0.196078, 0.215686, clamp((x - 0.343263) / 0.043707, 0.0, 1.0));
    if (x <= 0.427506) return mix(0.215686, 0.231373, clamp((x - 0.386970) / 0.040536, 0.0, 1.0));
    if (x <= 0.467164) return mix(0.231373, 0.250980, clamp((x - 0.427506) / 0.039657, 0.0, 1.0));
    if (x <= 0.505022) return mix(0.250980, 0.266667, clamp((x - 0.467164) / 0.037858, 0.0, 1.0));
    if (x <= 0.542332) return mix(0.266667, 0.286275, clamp((x - 0.505022) / 0.037311, 0.0, 1.0));
    if (x <= 0.581348) return mix(0.286275, 0.305882, clamp((x - 0.542332) / 0.039016, 0.0, 1.0));
    if (x <= 0.620850) return mix(0.305882, 0.329412, clamp((x - 0.581348) / 0.039503, 0.0, 1.0));
    if (x <= 0.663001) return mix(0.329412, 0.352941, clamp((x - 0.620850) / 0.042151, 0.0, 1.0));
    if (x <= 0.710596) return mix(0.352941, 0.384314, clamp((x - 0.663001) / 0.047595, 0.0, 1.0));
    if (x <= 0.765746) return mix(0.384314, 0.419608, clamp((x - 0.710596) / 0.055150, 0.0, 1.0));
    if (x <= 0.834591) return mix(0.419608, 0.470588, clamp((x - 0.765746) / 0.068845, 0.0, 1.0));
    if (x <= 0.989508) return mix(0.470588, 0.717647, clamp((x - 0.834591) / 0.154917, 0.0, 1.0));
    return 0.717647;
}
vec4 hz_n2_img(vec2 p) { return vec4(hz_n2_q0(hz_t3_noise(vec3(p, 0.0), 51.000000, 17.000000)), hz_n2_q1(hz_t3_noise(vec3(p, 0.0), 31.000000, 70.000000)), clamp(0.500970 + (hz_t3_hash(vec3(mod(floor(p * vec2(512.0, 512.0)), vec2(512.0, 512.0)), 123.000000)) - 0.5) * 1.006599, 0.000000, 1.000000), clamp(0.939058 + (hz_t3_hash(vec3(mod(floor(p * vec2(512.0, 512.0)), vec2(512.0, 512.0)), 176.000000)) - 0.5) * 0.372716, 0.749020, 1.000000)); }
const ivec2 hz_n2_size = ivec2(512, 512);
#ifndef texture
vec4 texture(bvec3 t, vec2 p) { return hz_n2_img(p); }
vec4 texture(bvec3 t, vec2 p, float bias) { return hz_n2_img(p); }
#endif
vec4 textureLod(bvec3 t, vec2 p, float lod) { return hz_n2_img(p); }
vec4 textureGrad(bvec3 t, vec2 p, vec2 dx, vec2 dy) { return hz_n2_img(p); }
vec4 texelFetch(bvec3 t, ivec2 c, int lod) { return hz_n2_img((vec2(c) + 0.5) / vec2(hz_n2_size)); }
ivec2 textureSize(bvec3 t, int lod) { return max(hz_n2_size >> lod, ivec2(1)); }
#endif

#define OVERWORLD
#define FSH

#include "/program/gbuffers_textured.glsl"
