/* 
BSL Shaders v8 Series by Capt Tatsu 
https://bitslablab.com 
*/ 

#version 120 
#define main hz_pack_main
#define HZ_NFIX_binormal
#define HZ_NFIX_normal
#define HZ_NFIX_tangent

#define END
#define VSH

#include "/program/gbuffers_terrain.glsl"

// face-normals (horizon-shaderport)
#undef main
varying vec3 hz_nfix_vpos;
void main() {
    hz_pack_main();
    hz_nfix_in_binormal = binormal;
    hz_nfix_in_normal = normal;
    hz_nfix_in_tangent = tangent;
    hz_nfix_vpos = (gl_ModelViewMatrix * gl_Vertex).xyz;
}
