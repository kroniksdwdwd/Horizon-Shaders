const float pi = 3.1415927;
float pi2wt = 6.2831854 * (frameTimeCounter * 24.0);

float GetNoise(vec2 pos) {
	return fract(sin(dot(pos, vec2(12.9898, 4.1414))) * 43758.5453);
}

float Noise2D(vec2 pos) {
    vec2 flr = floor(pos);
    vec2 frc = fract(pos);
    frc = frc * frc * (3.0 - 2.0 * frc);

    float n00 = GetNoise(flr);
    float n01 = GetNoise(flr + vec2(0.0, 1.0));
    float n10 = GetNoise(flr + vec2(1.0, 0.0));
    float n11 = GetNoise(flr + vec2(1.0, 1.0));

    float n0 = mix(n00, n01, frc.y);
    float n1 = mix(n10, n11, frc.y);

    return mix(n0, n1, frc.x) - 0.5;
}

vec3 CalcMove(vec3 pos, float density, float speed, vec2 mult) {
    pos = pos * density + frameTimeCounter * speed;
    vec3 wave = vec3(Noise2D(pos.yz), Noise2D(pos.xz + 0.333), Noise2D(pos.xy + 0.667));
    return wave * vec3(mult, mult.x);
}

vec3 getWavingBlocks(vec3 worldPos, float istopv, float skyLightMap) {
    vec3 wave = vec3(0.0);

    if (skyLightMap > 0.0) {
        vec3 pos = worldPos + cameraPosition;
        float speed = WAVING_SPEED * 1.0;
        float amp = WAVING_AMPLITUDE * 0.05;

        #ifdef WAVING_GRASS
        if (mc_Entity.x == 10304 || (mc_Entity.x >= 10035 && mc_Entity.x <= 10040)) {
            float grassWeight = max(istopv, 0.10);
            wave += CalcMove(pos, 0.35, speed, vec2(amp * 2.5, amp * 0.6)) * grassWeight;
        }
        #endif

        #ifdef WAVING_TALL_PLANT
        if (mc_Entity.x == 10305 || mc_Entity.x == 10306 || mc_Entity.x == 10311 || mc_Entity.x == 10312 || mc_Entity.x == 10318 || mc_Entity.x == 10319) {
            float plantHeight = max(istopv, 0.15);
            wave += CalcMove(pos, 0.35, speed * 0.95, vec2(amp * 3.5, amp * 1.5)) * plantHeight;
        }
        #endif

        #ifdef WAVING_VINE
        if (mc_Entity.x == 10315) {
            wave += CalcMove(pos, 0.35, speed * 1.25, vec2(amp * 1.2, amp * 1.2)); 
        }
        #endif

        #ifdef WAVING_LEAF
        if (mc_Entity.x == 10314) {
            wave += CalcMove(pos, 0.25, speed, vec2(amp * 0.8, amp * 0.8));
        }
        #endif

        return worldPos + wave * skyLightMap;
    }

    return worldPos;
}