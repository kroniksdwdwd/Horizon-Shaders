#ifdef OVERWORLD
#include "/lib/color/lightColor.glsl"
#endif

#ifdef NETHER
#include "/lib/color/netherColor.glsl"
#endif

#ifndef END
vec4 endColSqrt = vec4(vec3(END_R, END_G, END_B) / 255.0, 1.0) * END_I;
vec4 endCol = endColSqrt * endColSqrt;
#else
#include "/lib/color/endColor.glsl"
#endif

vec3 minLightColSqrt = vec3(MINLIGHT_R, MINLIGHT_G, MINLIGHT_B) * MINLIGHT_I / 255.0;
vec3 minLightCol	 = minLightColSqrt * minLightColSqrt * 0.04;