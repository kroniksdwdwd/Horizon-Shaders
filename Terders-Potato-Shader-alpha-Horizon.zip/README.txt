Terder's Potato Shader v1.1

Minecraft Java Edition shaderpack for Fabric + Sodium + Iris.
Built from the working v3/v4 gbuffers structure, with upgraded cinematic post processing, denser atmospheric fog, epic sunset grading, stronger shadows, and more natural water.

v1.1 Changes:
- Fixed harsh horizontal white line/band artifact where fog meets the sky:
  * Implemented smooth ray-angle elevation-based horizon fog falloff using true world ray direction.
  * Replaced screen-space horizon gradients with physically anchored atmospheric gradient.
  * Seamlessly blended horizon fog and sky color at the celestial horizon to eliminate hard cutoff lines.
  * Smoothed far view-distance fog falloff into the horizon atmosphere.
  * Suppressed sky horizon bloom artifacts while preserving vibrant sun glow, godrays, and celestial stars.

Install:
1. Put this .zip in .minecraft/shaderpacks
2. Select it in Iris Shader Packs
3. Enjoy!

If it fails, send .minecraft/logs/latest.log and the Iris shader compile error.
