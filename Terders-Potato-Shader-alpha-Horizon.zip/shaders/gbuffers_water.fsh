#version 330 compatibility

uniform sampler2D gtexture;
uniform sampler2D lightmap;
const float alphaTestRef = 0.1;
uniform float frameTimeCounter;
uniform vec3 shadowLightPosition;

in vec2 texcoord;
in vec2 lmcoord;
in vec4 glcolor;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

#define EPIC_WATER 1 // [0 1]
#define WATER_TINT 0.48 // [0.00 0.20 0.34 0.48 0.62]
#define WATER_CLARITY 0.78 // [0.55 0.65 0.78 0.88 1.00]
#define WATER_WAVE_SCALE 1.15 // [0.60 0.85 1.00 1.15 1.40 1.70]
#define WATER_SPECULAR 0.26 // [0.00 0.08 0.16 0.26 0.38 0.52]
#define WATER_CAUSTICS 0.10 // [0.00 0.04 0.08 0.10 0.16 0.24]

float waveHeight(vec2 p, float t) {
    p *= WATER_WAVE_SCALE;
    float h = 0.0;
    h += sin(dot(p, vec2( 1.00,  0.18)) * 18.0 + t * 0.82) * 0.45;
    h += sin(dot(p, vec2(-0.35,  0.94)) * 26.0 - t * 1.07) * 0.28;
    h += sin(dot(p, vec2( 0.74, -0.62)) * 41.0 + t * 0.55) * 0.16;
    h += sin((p.x + p.y) * 9.0 + t * 0.25) * 0.22;
    return h;
}

float causticPattern(vec2 p, float t) {
    p *= WATER_WAVE_SCALE;
    float a = sin(p.x * 34.0 + t * 0.95 + sin(p.y * 7.0));
    float b = sin(p.y * 29.0 - t * 0.82 + sin(p.x * 6.0));
    float c = sin((p.x + p.y) * 22.0 + t * 0.48);
    float lines = 1.0 - abs(a * b * 0.65 + c * 0.35);
    return pow(clamp(lines, 0.0, 1.0), 8.0);
}

void main() {
    float t = frameTimeCounter;
    vec2 uv = texcoord;

    #if EPIC_WATER == 1
        float rippleH = waveHeight(texcoord, t);
        float rippleHx = waveHeight(texcoord + vec2(0.003, 0.0), t) - rippleH;
        float rippleHy = waveHeight(texcoord + vec2(0.0, 0.003), t) - rippleH;
        vec2 rippleOffset = vec2(rippleHx, rippleHy) * 0.010;
        uv += rippleOffset;
    #endif

    vec4 albedo = texture(gtexture, uv) * glcolor;
    vec4 lm = texture(lightmap, lmcoord);
    albedo *= lm;

    if (albedo.a < alphaTestRef) {
        discard;
    }

    #if EPIC_WATER == 1
        float normalH = waveHeight(texcoord, t);
        float normalHx = waveHeight(texcoord + vec2(0.004, 0.0), t) - normalH;
        float normalHy = waveHeight(texcoord + vec2(0.0, 0.004), t) - normalH;
        vec3 n = normalize(vec3(-normalHx * 38.0, 1.0, -normalHy * 38.0));

        vec3 lightDir = normalize(shadowLightPosition);
        vec3 viewDir = normalize(vec3(0.0, 0.70, 0.95));
        vec3 halfDir = normalize(lightDir + viewDir);

        float sunFacing = clamp(dot(n, lightDir) * 0.5 + 0.5, 0.0, 1.0);
        float spec = pow(max(dot(n, halfDir), 0.0), 72.0) * WATER_SPECULAR;
        spec *= smoothstep(0.18, 1.0, lm.g);

        vec3 shallow = vec3(0.12, 0.57, 0.78);
        vec3 deep    = vec3(0.015, 0.13, 0.28);
        vec3 jade    = vec3(0.08, 0.42, 0.40);
        vec3 waterColor = mix(deep, shallow, clamp(lm.g * 1.30, 0.0, 1.0));
        waterColor = mix(waterColor, jade, 0.18);

        float caustics = causticPattern(texcoord, t) * WATER_CAUSTICS * smoothstep(0.35, 1.0, lm.g);
        vec3 causticColor = vec3(0.45, 0.85, 1.00) * caustics;

        albedo.rgb = mix(albedo.rgb, waterColor, WATER_TINT);
        albedo.rgb *= mix(0.88, 1.10, sunFacing);
        albedo.rgb += spec * vec3(0.95, 0.98, 1.00);
        albedo.rgb += causticColor;
        albedo.a = max(albedo.a * WATER_CLARITY, 0.64);
    #endif

    color = albedo;
}
