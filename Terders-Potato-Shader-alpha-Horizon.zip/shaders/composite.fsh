#version 330 compatibility

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform sampler2D shadowtex0;
uniform float viewWidth;
uniform float viewHeight;
uniform float frameTimeCounter;
uniform float near;
uniform float far;
uniform int worldTime;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 shadowLightPosition;

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

#define TONEMAP_STYLE 3 // [0 1 2 3] 0=Safe, 1=Filmic, 2=Epic, 3=Absolute Cinema
#define EXPOSURE 1.08 // [0.85 0.95 1.00 1.08 1.16 1.24]
#define SATURATION 1.22 // [0.90 1.00 1.10 1.22 1.34 1.48]
#define CONTRAST 1.13 // [0.95 1.00 1.06 1.13 1.20 1.28]
#define VIBRANCE 0.24 // [0.00 0.08 0.16 0.24 0.34 0.46]
#define BLOOM_STRENGTH 0.26 // [0.00 0.08 0.16 0.26 0.38 0.52]
#define BLOOM_RADIUS 3.00 // [1.00 2.00 3.00 4.00 5.00]
#define GODRAYS_STRENGTH 0.26 // [0.00 0.08 0.16 0.26 0.40 0.58]
#define SUNSET_INTENSITY 1.00 // [0.00 0.35 0.65 1.00 1.35 1.70]
#define SHADOW_STRENGTH 0.62 // [0.00 0.28 0.45 0.62 0.78 0.90]
#define SHADOW_QUALITY 3 // [0 1 2 3] 0=Off, 1=Fast, 2=Soft, 3=Cinematic
#define ATMOSPHERIC_FOG 0.34 // [0.00 0.10 0.20 0.34 0.50 0.70]
#define HORIZON_FOG 0.48 // [0.00 0.16 0.30 0.48 0.70 0.95]
#define VIGNETTE_STRENGTH 0.17 // [0.00 0.06 0.11 0.17 0.24 0.32]
#define SHARPEN_STRENGTH 0.11 // [0.00 0.04 0.08 0.11 0.15 0.20]
#define WARMTH 0.055 // [-0.050 -0.020 0.000 0.030 0.055 0.090]
#define FILM_GRAIN 0.006 // [0.000 0.003 0.006 0.010 0.016]

const int shadowMapResolution = 4096;
const float shadowDistance = 144.0;
const float shadowDistanceRenderMul = 1.0;

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

vec3 acesApprox(vec3 x) {
    const float a = 2.51;
    const float b = 0.03;
    const float c = 2.43;
    const float d = 0.59;
    const float e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

vec3 cinemaTonemap(vec3 x) {
    x = max(x, vec3(0.0));
    x = acesApprox(x * 1.18);
    x = pow(x, vec3(0.92));
    x = mix(vec3(luma(x)), x, 1.08);
    return clamp(x, 0.0, 1.0);
}

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float timeDistance(float t, float center) {
    float d = abs(t - center);
    return min(d, 24000.0 - d);
}

float sunsetFactor() {
    float t = mod(float(worldTime), 24000.0);
    float dusk = exp(-pow(timeDistance(t, 12000.0) / 2400.0, 2.0));
    float dawn = exp(-pow(timeDistance(t, 23000.0) / 2400.0, 2.0));
    return clamp(max(dusk, dawn) * SUNSET_INTENSITY, 0.0, 1.8);
}

float nightFactor() {
    float t = mod(float(worldTime), 24000.0);
    return smoothstep(12500.0, 15000.0, t) * (1.0 - smoothstep(21500.0, 23500.0, t));
}

vec3 projectAndDivide(mat4 projectionMatrix, vec3 position) {
    vec4 homPos = projectionMatrix * vec4(position, 1.0);
    return homPos.xyz / homPos.w;
}

vec3 distortShadowClipPos(vec3 shadowClipPos) {
    float distortionFactor = length(shadowClipPos.xy);
    distortionFactor += 0.10;
    shadowClipPos.xy /= distortionFactor;
    shadowClipPos.z *= 0.50;
    return shadowClipPos;
}

float linearDepth(float depth) {
    float z = depth * 2.0 - 1.0;
    return (2.0 * near * far) / max(far + near - z * (far - near), 0.0001);
}

vec3 blur5(vec2 uv, vec2 px) {
    vec3 s = texture(colortex0, uv).rgb * 4.0;
    s += texture(colortex0, uv + vec2( px.x, 0.0)).rgb;
    s += texture(colortex0, uv + vec2(-px.x, 0.0)).rgb;
    s += texture(colortex0, uv + vec2(0.0,  px.y)).rgb;
    s += texture(colortex0, uv + vec2(0.0, -px.y)).rgb;
    return s / 8.0;
}

vec3 bloomSample(vec2 uv, vec2 px) {
    vec3 s = vec3(0.0);
    s += texture(colortex0, uv).rgb * 3.0;
    s += texture(colortex0, uv + px * vec2(-1.0,  0.0)).rgb;
    s += texture(colortex0, uv + px * vec2( 1.0,  0.0)).rgb;
    s += texture(colortex0, uv + px * vec2( 0.0, -1.0)).rgb;
    s += texture(colortex0, uv + px * vec2( 0.0,  1.0)).rgb;
    s += texture(colortex0, uv + px * vec2(-2.0, -2.0)).rgb;
    s += texture(colortex0, uv + px * vec2( 2.0, -2.0)).rgb;
    s += texture(colortex0, uv + px * vec2(-2.0,  2.0)).rgb;
    s += texture(colortex0, uv + px * vec2( 2.0,  2.0)).rgb;
    s += texture(colortex0, uv + px * vec2(-4.0,  0.0)).rgb;
    s += texture(colortex0, uv + px * vec2( 4.0,  0.0)).rgb;
    s += texture(colortex0, uv + px * vec2( 0.0, -4.0)).rgb;
    s += texture(colortex0, uv + px * vec2( 0.0,  4.0)).rgb;
    return s / 15.0;
}

float shadowSample(vec3 shadowScreenPos) {
    if (shadowScreenPos.x <= 0.001 || shadowScreenPos.x >= 0.999 || shadowScreenPos.y <= 0.001 || shadowScreenPos.y >= 0.999 || shadowScreenPos.z <= 0.0 || shadowScreenPos.z >= 1.0) return 1.0;
    float mapDepth = texture(shadowtex0, shadowScreenPos.xy).r;
    return step(shadowScreenPos.z, mapDepth);
}

float softShadow(vec4 shadowClipPos) {
    #if SHADOW_QUALITY == 0
        return 1.0;
    #else
        float accum = 0.0;
        float count = 0.0;
        float radius = 1.20;
        #if SHADOW_QUALITY == 1
            for (int x = -1; x <= 1; x++) for (int y = -1; y <= 1; y++) {
                vec2 offset = vec2(float(x), float(y)) * radius / float(shadowMapResolution);
                vec4 sc = shadowClipPos + vec4(offset, 0.0, 0.0);
                sc.z -= 0.0020;
                sc.xyz = distortShadowClipPos(sc.xyz);
                vec3 ndc = sc.xyz / sc.w;
                accum += shadowSample(ndc * 0.5 + 0.5);
                count += 1.0;
            }
        #elif SHADOW_QUALITY == 2
            for (int x = -2; x <= 2; x++) for (int y = -2; y <= 2; y++) {
                vec2 offset = vec2(float(x), float(y)) * radius / float(shadowMapResolution);
                vec4 sc = shadowClipPos + vec4(offset, 0.0, 0.0);
                sc.z -= 0.0020;
                sc.xyz = distortShadowClipPos(sc.xyz);
                vec3 ndc = sc.xyz / sc.w;
                accum += shadowSample(ndc * 0.5 + 0.5);
                count += 1.0;
            }
        #else
            for (int x = -3; x <= 3; x++) for (int y = -3; y <= 3; y++) {
                vec2 o = vec2(float(x), float(y));
                float w = 1.0 / (1.0 + dot(o, o) * 0.12);
                vec2 offset = o * radius / float(shadowMapResolution);
                vec4 sc = shadowClipPos + vec4(offset, 0.0, 0.0);
                sc.z -= 0.0020;
                sc.xyz = distortShadowClipPos(sc.xyz);
                vec3 ndc = sc.xyz / sc.w;
                accum += shadowSample(ndc * 0.5 + 0.5) * w;
                count += w;
            }
        #endif
        return accum / max(count, 1.0);
    #endif
}

float getSceneShadow(float depth) {
    if (depth >= 0.9999) return 1.0;
    vec3 ndc = vec3(texcoord.xy, depth) * 2.0 - 1.0;
    vec3 viewPos = projectAndDivide(gbufferProjectionInverse, ndc);
    vec3 playerPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
    vec3 shadowViewPos = (shadowModelView * vec4(playerPos, 1.0)).xyz;
    vec4 shadowClipPos = shadowProjection * vec4(shadowViewPos, 1.0);
    return softShadow(shadowClipPos);
}

vec2 lightScreenPos() {
    vec4 lightClip = gl_ProjectionMatrix * vec4(shadowLightPosition, 1.0);
    return (lightClip.xy / lightClip.w) * 0.5 + 0.5;
}

float lightOnScreen() {
    vec4 lightClip = gl_ProjectionMatrix * vec4(shadowLightPosition, 1.0);
    vec2 ls = (lightClip.xy / lightClip.w) * 0.5 + 0.5;
    return step(0.0, lightClip.w) * step(-0.20, ls.x) * step(ls.x, 1.20) * step(-0.20, ls.y) * step(ls.y, 1.20);
}

float godRays(vec2 uv) {
    if (GODRAYS_STRENGTH <= 0.0) return 0.0;
    vec2 ls = lightScreenPos();
    vec2 delta = (ls - uv) * 0.040;
    vec2 p = uv;
    float ray = 0.0;
    float decay = 1.0;
    for (int i = 0; i < 18; i++) {
        p += delta;
        if (p.x < 0.0 || p.x > 1.0 || p.y < 0.0 || p.y > 1.0) break;
        float d = texture(depthtex0, p).r;
        float openSky = smoothstep(0.997, 1.0, d);
        ray += openSky * decay;
        decay *= 0.86;
    }
    return ray * 0.035 * lightOnScreen();
}

vec3 getPlayerRayDir(vec2 coord) {
    vec3 viewPosFar = projectAndDivide(gbufferProjectionInverse, vec3(coord * 2.0 - 1.0, 1.0));
    vec3 viewDir = normalize(viewPosFar);
    return normalize((gbufferModelViewInverse * vec4(viewDir, 0.0)).xyz);
}

vec3 getAtmosphereColor(vec3 dir, float sunset, float night) {
    float y = dir.y;

    vec3 dayHorizon    = vec3(0.58, 0.72, 0.88);
    vec3 dayZenith     = vec3(0.24, 0.46, 0.88);

    vec3 sunsetHorizon = vec3(1.00, 0.52, 0.22);
    vec3 sunsetMid     = vec3(0.92, 0.36, 0.60);
    vec3 sunsetZenith  = vec3(0.20, 0.12, 0.42);

    vec3 nightHorizon  = vec3(0.040, 0.065, 0.150);
    vec3 nightZenith   = vec3(0.012, 0.020, 0.055);

    vec3 horizonColor = dayHorizon;
    horizonColor = mix(horizonColor, sunsetHorizon, clamp(sunset, 0.0, 1.0));
    horizonColor = mix(horizonColor, nightHorizon, night * 0.90);

    if (y >= 0.0) {
        float elev = clamp(y, 0.0, 1.0);
        float broadCos = 0.5 - 0.5 * cos(elev * 3.14159265);

        vec3 daySky = mix(horizonColor, dayZenith, broadCos);

        float sunsetT1 = smoothstep(0.0, 0.42, elev);
        float sunsetT2 = smoothstep(0.25, 0.90, elev);
        vec3 sunsetSky = mix(horizonColor, sunsetMid, sunsetT1);
        sunsetSky = mix(sunsetSky, sunsetZenith, sunsetT2);

        vec3 nightSky = mix(horizonColor, nightZenith, broadCos);

        vec3 skyGrade = mix(daySky, sunsetSky, clamp(sunset, 0.0, 1.0));
        return mix(skyGrade, nightSky, night * 0.90);
    } else {
        float voidT = smoothstep(0.0, -0.65, y);
        return mix(horizonColor, nightHorizon * 0.40, voidT);
    }
}

vec3 applyAtmosphere(vec3 color, vec3 base, float depth, float sunset, float night, vec2 uv) {
    bool isSky = (depth >= 0.99999);
    vec3 playerDir = getPlayerRayDir(uv);
    vec3 atmosColor = getAtmosphereColor(playerDir, sunset, night);

    if (isSky) {
        float starLuma = max(0.0, luma(base) - 0.04) * night;
        vec3 stars = base * (starLuma * 1.5);
        return atmosColor + stars;
    } else {
        vec3 ndc = vec3(uv, depth) * 2.0 - 1.0;
        vec3 geoViewPos = projectAndDivide(gbufferProjectionInverse, ndc);
        float viewDist = length(geoViewPos);

        float fogStart = far * mix(0.45, 0.15, clamp(ATMOSPHERIC_FOG, 0.0, 1.0));
        float fogEnd   = far * 0.88;
        float terrainFog = smoothstep(fogStart, fogEnd, viewDist);

        return mix(color, atmosColor, terrainFog);
    }
}

void main() {
    vec2 uv = texcoord;
    vec2 px = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    float depth = texture(depthtex0, uv).r;
    bool isSky = (depth >= 0.99999);
    float sunset = sunsetFactor();
    float night = nightFactor();

    vec3 base = texture(colortex0, uv).rgb;
    vec3 color = base * EXPOSURE;

    if (!isSky) {
        float shadow = getSceneShadow(depth);
        float shadowMask = mix(1.0 - SHADOW_STRENGTH, 1.0, shadow);
        color *= shadowMask;

        vec3 local = blur5(uv, px);
        color += (base - local) * SHARPEN_STRENGTH;
    }

    vec3 bloomBlur = bloomSample(uv, px * BLOOM_RADIUS);
    float threshold = mix(0.78, 0.56, clamp(sunset, 0.0, 1.0));
    vec3 bright = max(bloomBlur - vec3(threshold), vec3(0.0));

    vec2 ls = lightScreenPos();
    float sunDist = length((uv - ls) * vec2(viewWidth / viewHeight, 1.0));
    float sunGlowMask = exp(-sunDist * 4.0);

    if (isSky) {
        bright *= clamp(sunGlowMask * 2.0 + sunset * 0.85, 0.0, 1.0);
    }
    color += bright * BLOOM_STRENGTH * mix(vec3(0.80, 0.92, 1.00), vec3(1.00, 0.52, 0.24), clamp(sunset, 0.0, 1.0));

    color = applyAtmosphere(color, base, depth, sunset, night, uv);

    float sunGlow = exp(-sunDist * 8.0) * lightOnScreen() * (isSky ? 1.0 : smoothstep(0.997, 1.0, depth));
    color += sunGlow * vec3(1.0, 0.58, 0.20) * (0.55 + sunset * 1.65);

    float rays = godRays(uv) * GODRAYS_STRENGTH;
    color += rays * mix(vec3(0.90, 0.84, 0.62), vec3(1.00, 0.42, 0.18), clamp(sunset, 0.0, 1.0));

    #if TONEMAP_STYLE == 1
        color = acesApprox(color);
    #elif TONEMAP_STYLE == 2
        color = acesApprox(color * 1.10);
    #elif TONEMAP_STYLE == 3
        color = cinemaTonemap(color);
    #else
        color = clamp(color, 0.0, 1.0);
    #endif

    color = (color - 0.5) * CONTRAST + 0.5;

    float y = luma(color);
    vec3 warmHi = vec3(WARMTH * (1.0 + sunset * 1.4), WARMTH * 0.35 * sunset, -WARMTH * 0.52);
    vec3 coolSh = vec3(-0.025, -0.010, 0.045) * (1.0 - smoothstep(0.15, 0.65, y));
    color += warmHi * smoothstep(0.30, 1.0, y) + coolSh;

    color = mix(vec3(luma(color)), color, SATURATION);
    float mx = max(color.r, max(color.g, color.b));
    float mn = min(color.r, min(color.g, color.b));
    color = mix(color, vec3(mx), (mx - mn) * -VIBRANCE);

    vec2 centered = uv * 2.0 - 1.0;
    centered.x *= viewWidth / viewHeight;
    float vignette = smoothstep(1.58, 0.32, length(centered));
    color *= mix(1.0 - VIGNETTE_STRENGTH, 1.0, vignette);

    float grain = hash12(gl_FragCoord.xy + frameTimeCounter * 23.0) - 0.5;
    color += grain * FILM_GRAIN;

    outColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
