#version 330 compatibility

uniform sampler2D gtexture;
uniform sampler2D lightmap;
const float alphaTestRef = 0.1;

in vec2 texcoord;
in vec2 lmcoord;
in vec4 glcolor;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

void main() {
    vec4 albedo = texture(gtexture, texcoord) * glcolor;
    albedo *= texture(lightmap, lmcoord);

    if (albedo.a < alphaTestRef) {
        discard;
    }

    color = albedo;
}
